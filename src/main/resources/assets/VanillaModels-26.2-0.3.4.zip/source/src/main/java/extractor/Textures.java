package extractor;

import com.google.gson.*;
import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;
import javax.imageio.ImageIO;

/**
 * Deterministic texture preparation and self-check.
 *
 * Modes:
 *   copy  - embed the official PNG bytes unchanged and assert byte identity.
 *   tint  - multiply RGB by an official ARGB colour, keep alpha, then decode
 *           the written image and assert every channel is within half a level.
 *   over  - source-over composite an overlay (optionally tinted) onto a base;
 *           used by later appearance variants.  The result is decoded and
 *           checked against the same integer formula.
 */
public final class Textures {
  static final Gson GSON=new GsonBuilder().setPrettyPrinting().create();
  static int tint(int pixel,int argb,int shift){return Math.round(((pixel>>>shift)&255)*((argb>>>shift)&255)/255f);}
  static byte[] sha(byte[] data)throws Exception{return MessageDigest.getInstance("SHA-256").digest(data);}
  static String hex(byte[] data){StringBuilder b=new StringBuilder();for(byte x:data)b.append(String.format("%02x",x));return b.toString();}
  static byte[] read(ZipFile jar,String path)throws Exception{
    ZipEntry e=jar.getEntry("assets/minecraft/"+path);
    if(e==null)throw new IllegalArgumentException("Missing official texture: "+path);
    return jar.getInputStream(e).readAllBytes();
  }
  static BufferedImage decode(byte[] data)throws Exception{
    BufferedImage image=ImageIO.read(new java.io.ByteArrayInputStream(data));
    if(image==null||image.getWidth()<=0)throw new IllegalArgumentException("PNG decode failed");
    return image;
  }
  static int over(int base,int overlay,int tintArgb){
    int oa=overlay>>>24,ba=base>>>24,outA=oa+Math.round(ba*(255-oa)/255f),outPixel=outA<<24;
    for(int shift:new int[]{0,8,16}){
      int oc=tint(overlay,tintArgb,shift),bc=(base>>>shift)&255;
      int c=Math.round((oc*oa+bc*ba*(255-oa)/255f)/Math.max(1,outA));
      outPixel|=Math.min(255,c)<<shift;
    }
    return outPixel;
  }
  static boolean masked(JsonObject layer,int x,int y){
    if(!layer.has("maskRects"))return true;
    for(JsonElement raw:layer.getAsJsonArray("maskRects")){
      JsonArray r=raw.getAsJsonArray();
      if(x>=r.get(0).getAsInt()&&y>=r.get(1).getAsInt()&&x<r.get(2).getAsInt()&&y<r.get(3).getAsInt())return true;
    }
    return false;
  }
  public static void main(String[] args)throws Exception{
    Path jarPath=Path.of(args[0]),jobsPath=Path.of(args[1]),reportPath=Path.of(args[2]);
    JsonArray jobs=JsonParser.parseString(Files.readString(jobsPath)).getAsJsonObject().getAsJsonArray("jobs");
    JsonArray results=new JsonArray();
    try(ZipFile jar=new ZipFile(jarPath.toFile())){
      for(JsonElement raw:jobs){
        JsonObject job=raw.getAsJsonObject();
        String name=job.get("name").getAsString();
        String source=job.get("source").getAsString();
        Path out=Path.of(job.get("out").getAsString());Files.createDirectories(out.getParent());
        String mode=job.has("mode")?job.get("mode").getAsString():"copy";
        byte[] sourceBytes=read(jar,source);BufferedImage src=decode(sourceBytes);
        BufferedImage dst;
        if(mode.equals("copy")){
          Files.write(out,sourceBytes);
          byte[] written=Files.readAllBytes(out);
          if(!Arrays.equals(written,sourceBytes))throw new AssertionError("copy changed PNG bytes: "+name);
          dst=src;
        }else if(mode.equals("tint")){
          int argb=job.get("tintArgb").getAsInt();
          dst=new BufferedImage(src.getWidth(),src.getHeight(),BufferedImage.TYPE_INT_ARGB);
          for(int y=0;y<src.getHeight();y++)for(int x=0;x<src.getWidth();x++){
            int p=src.getRGB(x,y),o=p&0xff000000;
            for(int shift:new int[]{0,8,16})o|=tint(p,argb,shift)<<shift;
            dst.setRGB(x,y,o);
          }
          ImageIO.write(dst,"png",out.toFile());
          BufferedImage check=decode(Files.readAllBytes(out));
          if(check.getWidth()!=src.getWidth()||check.getHeight()!=src.getHeight())throw new AssertionError("tint changed dimensions: "+name);
          for(int y=0;y<src.getHeight();y++)for(int x=0;x<src.getWidth();x++){
            int a=src.getRGB(x,y),b=check.getRGB(x,y);
            if((a>>>24)!=(b>>>24))throw new AssertionError("tint changed alpha: "+name);
            for(int shift:new int[]{0,8,16})if(Math.abs(((b>>>shift)&255)-((a>>>shift)&255)*((argb>>>shift)&255)/255d)>0.500001)throw new AssertionError("tint mismatch: "+name);
          }
        }else if(mode.equals("over")){
          BufferedImage overlay=decode(read(jar,job.get("overlay").getAsString()));
          if(overlay.getWidth()!=src.getWidth()||overlay.getHeight()!=src.getHeight())throw new IllegalArgumentException("overlay size differs: "+name);
          int tintArgb=job.has("overlayTintArgb")?job.get("overlayTintArgb").getAsInt():0xffffffff;
          dst=new BufferedImage(src.getWidth(),src.getHeight(),BufferedImage.TYPE_INT_ARGB);
          for(int y=0;y<src.getHeight();y++)for(int x=0;x<src.getWidth();x++){
            int bp=src.getRGB(x,y),op=overlay.getRGB(x,y);
            int oa=op>>>24,ba=bp>>>24;
            if(job.has("binaryAlpha") && job.get("binaryAlpha").getAsBoolean() && oa!=0 && oa!=255)
              throw new IllegalArgumentException("Cutout overlay is not binary alpha: "+name);
            dst.setRGB(x,y,over(bp,op,tintArgb));
          }
          ImageIO.write(dst,"png",out.toFile());
          BufferedImage check=decode(Files.readAllBytes(out));
          if(check.getWidth()!=src.getWidth()||check.getHeight()!=src.getHeight())throw new AssertionError("overlay changed dimensions: "+name);
          if(job.has("binaryAlpha") && job.get("binaryAlpha").getAsBoolean()) {
            for(int y=0;y<src.getHeight();y++)for(int x=0;x<src.getWidth();x++) {
              int op=overlay.getRGB(x,y),expected=(op>>>24)==255?op:src.getRGB(x,y);
              int actual=check.getRGB(x,y);
              if((expected>>>24)==0) {if((actual>>>24)!=0)throw new AssertionError("Composite alpha mismatch");}
              else if(actual!=expected)throw new AssertionError("Composite pixel mismatch: "+name);
            }
          }
        }else if(mode.equals("stack")){
          JsonArray layerSpecs=job.getAsJsonArray("overlays");List<BufferedImage> layers=new ArrayList<>();
          dst=new BufferedImage(src.getWidth(),src.getHeight(),BufferedImage.TYPE_INT_ARGB);
          for(int y=0;y<src.getHeight();y++)for(int x=0;x<src.getWidth();x++)dst.setRGB(x,y,src.getRGB(x,y));
          for(JsonElement rawLayer:layerSpecs){
            JsonObject layer=rawLayer.getAsJsonObject();BufferedImage overlay=decode(read(jar,layer.get("source").getAsString()));
            if(overlay.getWidth()!=src.getWidth()||overlay.getHeight()!=src.getHeight())throw new IllegalArgumentException("stack overlay size differs: "+name);
            boolean binary=layer.has("binaryAlpha")&&layer.get("binaryAlpha").getAsBoolean();
            int overlayTint=layer.has("tintArgb")?layer.get("tintArgb").getAsInt():0xffffffff;
            for(int y=0;y<src.getHeight();y++)for(int x=0;x<src.getWidth();x++)if(masked(layer,x,y)){
              int op=overlay.getRGB(x,y),oa=op>>>24;
              if(binary&&oa!=0&&oa!=255)throw new IllegalArgumentException("Stack overlay is not binary alpha: "+name);
              dst.setRGB(x,y,over(dst.getRGB(x,y),op,overlayTint));
            }
            layers.add(overlay);
          }
          ImageIO.write(dst,"png",out.toFile());BufferedImage check=decode(Files.readAllBytes(out));
          for(int y=0;y<src.getHeight();y++)for(int x=0;x<src.getWidth();x++){
            int expected=src.getRGB(x,y);
            for(int i=0;i<layers.size();i++){
              JsonObject layer=layerSpecs.get(i).getAsJsonObject();if(!masked(layer,x,y))continue;
              int tintArgb=layer.has("tintArgb")?layer.get("tintArgb").getAsInt():0xffffffff;
              expected=over(expected,layers.get(i).getRGB(x,y),tintArgb);
            }
            int actual=check.getRGB(x,y);
            if((expected>>>24)==0){if((actual>>>24)!=0)throw new AssertionError("Stack composite alpha mismatch: "+name);}
            else if(actual!=expected)throw new AssertionError("Stack composite pixel mismatch: "+name);
          }
        }else throw new IllegalArgumentException("Unknown texture mode: "+mode);
        JsonObject result=new JsonObject();
        result.addProperty("name",name);result.addProperty("path",out.toString());result.addProperty("mode",mode);
        result.addProperty("width",dst.getWidth());result.addProperty("height",dst.getHeight());
        result.addProperty("sha256",hex(sha(Files.readAllBytes(out))));result.addProperty("size",Files.size(out));
        results.add(result);
      }
    }
    JsonObject report=new JsonObject();report.add("textures",results);
    Files.writeString(reportPath,GSON.toJson(report)+"\n");
    System.out.println("Prepared and self-checked "+results.size()+" textures");
  }
}
