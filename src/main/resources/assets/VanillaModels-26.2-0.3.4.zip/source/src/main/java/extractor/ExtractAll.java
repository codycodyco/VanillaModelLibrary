package extractor;

import com.google.gson.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

/**
 * Enumerates the official 26.2 entity registry and extracts the default adult
 * appearance of every non-MISC mob through its real EntityRenderer.
 *
 * Nothing here assumes that an entity id equals a model layer or a texture
 * file.  Renderers are instantiated with a recording EntityModelSet, so every
 * model layer they bake and every model instance they hold is discovered from
 * the official client itself.  Textures come from the renderer's own
 * getTextureLocation; data-driven variants fall back to the built-in variant
 * registry JSON in the same jar.
 */
public final class ExtractAll {
  static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
  static final List<String> PART_FIELDS = List.of("x","y","z","xRot","yRot","zRot","xScale","yScale","zScale","visible","skipDraw");

  static Field field(Class<?> c,String name)throws Exception{Field f=c.getDeclaredField(name);f.setAccessible(true);return f;}
  static Object unsafe()throws Exception{Class<?> u=Class.forName("sun.misc.Unsafe");Field f=u.getDeclaredField("theUnsafe");f.setAccessible(true);return f.get(null);}
  static Object alloc(Class<?> c)throws Exception{Object u=unsafe();return u.getClass().getMethod("allocateInstance",Class.class).invoke(u,c);}

  static final class Recorder extends EntityModelSet {
    final List<ModelLayerLocation> order=new ArrayList<>();
    final List<ModelPart> roots=new ArrayList<>();
    Recorder(Map<ModelLayerLocation,LayerDefinition> roots){super(roots);}
    @Override public ModelPart bakeLayer(ModelLayerLocation l){
      ModelPart p=super.bakeLayer(l);order.add(l);roots.add(p);return p;
    }
    String layerOf(Object part){
      for(int i=0;i<roots.size();i++) if(contains(roots.get(i),part)) return order.get(i).model()+"#"+order.get(i).layer();
      return null;
    }
  }
  static boolean contains(Object root,Object target){
    if(root==target)return true;
    try{
      @SuppressWarnings("unchecked") Map<String,Object> children=(Map<String,Object>)field(root.getClass(),"children").get(root);
      for(Object child:children.values()) if(contains(child,target)) return true;
    }catch(Exception ignored){}
    return false;
  }

  static JsonElement tree(Object part)throws Exception{
    JsonObject out=new JsonObject();
    for(String name:PART_FIELDS) out.add(name,GSON.toJsonTree(field(part.getClass(),name).get(part)));
    JsonArray cubes=new JsonArray();
    for(Object cube:(List<?>)field(part.getClass(),"cubes").get(part)){
      JsonArray faces=new JsonArray();
      for(Object face:(Object[])field(cube.getClass(),"polygons").get(cube)){
        JsonObject fo=new JsonObject();JsonArray vertices=new JsonArray();
        for(Object vertex:(Object[])face.getClass().getMethod("vertices").invoke(face)){
          JsonArray a=new JsonArray();
          for(String name:List.of("x","y","z","u","v")) a.add((Number)vertex.getClass().getMethod(name).invoke(vertex));
          vertices.add(a);
        }
        fo.add("vertices",vertices);
        JsonArray normal=new JsonArray();Object n=face.getClass().getMethod("normal").invoke(face);
        for(String name:List.of("x","y","z")) normal.add((Number)n.getClass().getMethod(name).invoke(n));
        fo.add("normal",normal);faces.add(fo);
      }
      cubes.add(faces);
    }
    out.add("cubes",cubes);
    JsonObject children=new JsonObject();
    @SuppressWarnings("unchecked") Map<String,Object> map=(Map<String,Object>)field(part.getClass(),"children").get(part);
    for(String name:new TreeSet<>(map.keySet())) children.add(name,tree(map.get(name)));
    out.add("children",children);
    return out;
  }

  static Object modelField(Object renderer)throws Exception{
    for(Class<?> c=renderer.getClass();c!=null&&c!=Object.class;c=c.getSuperclass()){
      try{Field f=c.getDeclaredField("model");f.setAccessible(true);return f.get(renderer);}catch(NoSuchFieldException ignored){}
    }
    return null;
  }
  static Object state(Object renderer)throws Exception{return renderer.getClass().getMethod("createRenderState").invoke(renderer);}
  static Object rootOf(Object model)throws Exception{return model.getClass().getMethod("root").invoke(model);}
  static void set(Object object,String name,Object value)throws Exception{field(object.getClass(),name).set(object,value);}
  static void setIfPresent(Object object,String name,Object value){
    for(Class<?> c=object.getClass();c!=null&&c!=Object.class;c=c.getSuperclass()){
      try{Field f=c.getDeclaredField(name);f.setAccessible(true);f.set(object,value);return;}catch(Exception ignored){}
    }
  }
  static String setupAnim(Object model,Object state){
    try{
      Method found=null;
      for(Method m:model.getClass().getMethods()){
        if(!m.getName().equals("setupAnim")||m.getParameterCount()!=1)continue;
        Class<?> p=m.getParameterTypes()[0];
        if(p!=Object.class&&p.isAssignableFrom(state.getClass())){found=m;break;}
      }
      if(found==null)throw new NoSuchMethodException("setupAnim for "+state.getClass().getName());
      found.invoke(model,state);return "ok";
    }catch(Throwable t){
      try{model.getClass().getMethod("resetPose").invoke(model);}catch(Throwable ignored){}
      Throwable cause=t instanceof InvocationTargetException ? ((InvocationTargetException)t).getTargetException() : t;
      return "failed: "+cause;
    }
  }
  static void setDefaults(Object state){
    setIfPresent(state,"isBaby",false);
    setIfPresent(state,"isInvisibleToPlayer",false);
    setIfPresent(state,"isSheared",false);
    setIfPresent(state,"isJebSheep",false);
    setIfPresent(state,"isAngry",false);
    setIfPresent(state,"isSitting",false);
    setIfPresent(state,"isCrouching",false);
    setIfPresent(state,"isPassenger",false);
    setIfPresent(state,"isUsingItem",false);
    setIfPresent(state,"isAggressive",false);
  }

  static Object invokeTexture(Object renderer,Object state)throws Exception{
    Method found=null;
    for(Method m:renderer.getClass().getMethods()){
      if(!m.getName().equals("getTextureLocation")||m.getParameterCount()!=1)continue;
      if(m.getParameterTypes()[0].isAssignableFrom(state.getClass())){found=m;break;}
    }
    if(found==null)throw new NoSuchMethodException("getTextureLocation");
    return found.invoke(renderer,state);
  }
  static String texturePath(Object renderer,Object state,ZipFile jar,String entityPath){
    try{
      String text=String.valueOf(invokeTexture(renderer,state));
      if(!text.contains("missingno")) return text;
    }catch(Throwable ignored){}
    return variantFallback(jar,entityPath);
  }
  static String variantFallback(ZipFile jar,String entityPath){
    String prefix="data/minecraft/"+entityPath+"_variant/";
    List<String> names=jar.stream().map(ZipEntry::getName).filter(n->n.startsWith(prefix)&&n.endsWith(".json")).sorted().toList();
    if(names.isEmpty())return null;
    String chosen=names.get(0);
    for(String name:names){
      try{
        JsonObject o=JsonParser.parseString(new String(jar.getInputStream(jar.getEntry(name)).readAllBytes(),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
        JsonArray conditions=o.has("spawn_conditions")?o.getAsJsonArray("spawn_conditions"):new JsonArray();
        for(JsonElement c:conditions){
          JsonObject co=c.getAsJsonObject();
          if(co.has("priority")&&co.get("priority").getAsInt()==0){chosen=name;break;}
        }
      }catch(Exception ignored){}
    }
    try{
      JsonObject o=JsonParser.parseString(new String(jar.getInputStream(jar.getEntry(chosen)).readAllBytes(),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
      String asset=o.get("asset_id").getAsString();
      if(asset.startsWith("minecraft:"))asset=asset.substring("minecraft:".length());
      return "minecraft:textures/"+asset+".png";
    }catch(Exception e){return null;}
  }

  static boolean isCandidate(EntityType<?> type) {
    // Villagers are living mobs, but the official spawning category is MISC.
    return type.getCategory()!=MobCategory.MISC ||
        BuiltInRegistries.ENTITY_TYPE.getKey(type).toString().equals("minecraft:villager");
  }

  static JsonObject inventoryEntry(EntityType<?> type,EntityRendererProvider<?> provider,Context context,Map<ModelLayerLocation,LayerDefinition> definitions)throws Exception{
    Identifier id=BuiltInRegistries.ENTITY_TYPE.getKey(type);
    JsonObject o=new JsonObject();
    o.addProperty("entityType",id.toString());
    o.addProperty("category",type.getCategory().getName());
    o.addProperty("canSummon",type.canSummon());
    o.addProperty("width",type.getWidth());
    o.addProperty("height",type.getHeight());
    boolean candidate=isCandidate(type);
    o.addProperty("candidate",candidate);
    if(!candidate)o.addProperty("excludedReason","EntityType category MISC is not a creature or monster");
    o.addProperty("hasRenderer",provider!=null);
    if(provider==null)return o;
    Recorder recorder=new Recorder(definitions);
    Field modelSet=Context.class.getDeclaredField("modelSet");modelSet.setAccessible(true);modelSet.set(context,recorder);
    try{
      Object renderer=provider.create(context);
      o.addProperty("renderer",renderer.getClass().getName());
      Object state=state(renderer);
      o.addProperty("state",state.getClass().getName());
      Object model=modelField(renderer);
      if(model!=null)o.addProperty("baseModel",model.getClass().getName());
      JsonArray layers=new JsonArray();
      for(ModelLayerLocation layer:recorder.order)layers.add(layer.model()+"#"+layer.layer());
      o.add("bakedLayers",layers);
      JsonArray models=new JsonArray();
      for(Class<?> c=renderer.getClass();c!=null&&c!=Object.class;c=c.getSuperclass()){
        for(Field f:c.getDeclaredFields()){
          if(Model.class.isAssignableFrom(f.getType())){f.setAccessible(true);Object m=f.get(renderer);if(m!=null)models.add(f.getType().getName());}
        }
      }
      o.add("modelFields",models);
      try{
        Object texture=invokeTexture(renderer,state);
        o.addProperty("defaultTexture",String.valueOf(texture));
      }catch(Throwable ignored){}
    }catch(Throwable t){
      o.addProperty("rendererError",String.valueOf(t));
    }
    return o;
  }

  static JsonObject modelEntry(String key,String field,Object model,Object state,Recorder recorder,boolean baby)throws Exception{
    JsonObject o=new JsonObject();
    o.addProperty("key",key);o.addProperty("field",field);o.addProperty("age",baby?"baby":"adult");
    o.addProperty("model",model.getClass().getName());
    Object root=rootOf(model);o.addProperty("layer",recorder.layerOf(root));
    setIfPresent(state,"isBaby",baby);
    o.addProperty("setupAnim",setupAnim(model,state));
    o.add("tree",tree(root));
    return o;
  }
  static void collectModels(Object renderer,Object state,Object base,Recorder recorder,JsonArray out,Set<Integer> seen)throws Exception{
    for(Class<?> c=renderer.getClass();c!=null&&c!=Object.class;c=c.getSuperclass()){
      for(Field f:c.getDeclaredFields()){
        f.setAccessible(true);Object value;
        try{value=f.get(renderer);}catch(Throwable t){continue;}
        if(value==null)continue;
        String fieldName=f.getName();
        if(Model.class.isAssignableFrom(f.getType())){
          if(value==base||!seen.add(System.identityHashCode(value)))continue;
          out.add(modelEntry(fieldName,fieldName,value,state,recorder,fieldName.toLowerCase(Locale.ROOT).contains("baby")));
        }else if(Map.class.isAssignableFrom(f.getType())){
          for(var entry:((Map<?,?>)value).entrySet()){
            Object v=entry.getValue();String suffix=String.valueOf(entry.getKey());
            if(v instanceof Model model){
              if(model==base||!seen.add(System.identityHashCode(model)))continue;
              out.add(modelEntry(fieldName+"."+suffix,fieldName,model,state,recorder,suffix.toLowerCase(Locale.ROOT).contains("baby")));
            }else if(v!=null){
              for(String part:List.of("adultModel","babyModel")){
                try{
                  Object model=v.getClass().getMethod(part).invoke(v);
                  if(model==null||model==base||!seen.add(System.identityHashCode(model)))continue;
                  out.add(modelEntry(fieldName+"."+suffix+"."+part,fieldName,model,state,recorder,part.equals("babyModel")));
                }catch(NoSuchMethodException ignored){}
              }
            }
          }
        }
      }
    }
    setIfPresent(state,"isBaby",false);
  }
  public static void main(String[] args)throws Exception{
    Path output=Path.of(args[0]);Path jarPath=Path.of(args[1]);Files.createDirectories(output.resolve("entities"));
    Class.forName("net.minecraft.SharedConstants").getMethod("tryDetectVersion").invoke(null);
    Class.forName("net.minecraft.server.Bootstrap").getMethod("bootStrap").invoke(null);
    Map<ModelLayerLocation,LayerDefinition> definitions=LayerDefinitions.createRoots();
    Recorder recorder=new Recorder(definitions);
    Context context=(Context)alloc(Context.class);
    Field modelSet=Context.class.getDeclaredField("modelSet");modelSet.setAccessible(true);modelSet.set(context,recorder);
    @SuppressWarnings("unchecked") Map<EntityType<?>,EntityRendererProvider<?>> providers=(Map<EntityType<?>,EntityRendererProvider<?>>)field(EntityRenderers.class,"PROVIDERS").get(null);

    try(ZipFile jar=new ZipFile(jarPath.toFile())){
      JsonArray inventory=new JsonArray();
      int candidates=0,extracted=0,failed=0;
      for(EntityType<?> type:BuiltInRegistries.ENTITY_TYPE){
        Identifier id=BuiltInRegistries.ENTITY_TYPE.getKey(type);
        EntityRendererProvider<?> provider=providers.get(type);
        inventory.add(inventoryEntry(type,provider,context,definitions));
        if(!isCandidate(type)) continue;
        modelSet.set(context,recorder);
        candidates++;
        String path=id.getPath();
        JsonObject out=new JsonObject();
        out.addProperty("entityType",id.toString());
        out.addProperty("category",type.getCategory().getName());
        try{
          if(provider==null)throw new IllegalStateException("No registered EntityRenderer provider");
          recorder.order.clear();recorder.roots.clear();
          Object renderer=provider.create(context);
          out.addProperty("renderer",renderer.getClass().getName());
          Object state=state(renderer);setDefaults(state);
          out.addProperty("state",state.getClass().getName());
          Object base=modelField(renderer);
          if(base==null)throw new IllegalStateException("Renderer has no base model field");
          Object baseRoot=rootOf(base);
          String baseLayer=recorder.layerOf(baseRoot);
          String texture=texturePath(renderer,state,jar,path);
          out.addProperty("baseModel",base.getClass().getName());
          out.addProperty("baseLayer",baseLayer);
          out.addProperty("texture",texture);
          // Bind pose is captured before setupAnim.  It is only used for entities
          // whose official idle pose cannot be expressed by a single RP Engine
          // static item model (currently zombie arms).
          JsonObject bindEntry=new JsonObject();
          bindEntry.addProperty("role","base-bind");
          bindEntry.addProperty("layer",baseLayer);
          bindEntry.addProperty("model",base.getClass().getName());
          bindEntry.add("tree",tree(baseRoot));
          out.add("baseBind",bindEntry);
          out.addProperty("setupAnim",setupAnim(base,state));
          JsonObject baseEntry=new JsonObject();
          baseEntry.addProperty("role","base");
          baseEntry.addProperty("layer",baseLayer);
          baseEntry.addProperty("model",base.getClass().getName());
          baseEntry.add("tree",tree(baseRoot));
          out.add("base",baseEntry);
          JsonArray rendererModels=new JsonArray();
          Set<Integer> seen=new HashSet<>();
          seen.add(System.identityHashCode(base));
          collectModels(renderer,state,base,recorder,rendererModels,seen);
          out.add("rendererModels",rendererModels);
          try{out.addProperty("woolColor",(Integer)state.getClass().getMethod("getWoolColor").invoke(state));}catch(Throwable ignored){}
          // Every model instance held by a render layer is exported.  The Python
          // build selects only roles needed by the default appearance.
          JsonArray layers=new JsonArray();
          Object layerList=null;
          for(Class<?> c=renderer.getClass();c!=null&&c!=Object.class;c=c.getSuperclass()){
            try{Field f=c.getDeclaredField("layers");f.setAccessible(true);layerList=f.get(renderer);break;}catch(NoSuchFieldException ignored){}
          }
          if(layerList instanceof List<?> list){
            for(Object layer:list){
              JsonObject layerInfo=new JsonObject();
              layerInfo.addProperty("layerClass",layer.getClass().getName());
              JsonArray models=new JsonArray();
              for(Class<?> c=layer.getClass();c!=null&&c!=Object.class;c=c.getSuperclass()){
                for(Field f:c.getDeclaredFields()){
                  if(!Model.class.isAssignableFrom(f.getType()))continue;
                  f.setAccessible(true);Object model=f.get(layer);if(model==null)continue;
                  JsonObject mo=new JsonObject();
                  mo.addProperty("field",f.getName());
                  mo.addProperty("model",model.getClass().getName());
                  Object root=rootOf(model);
                  mo.addProperty("layer",recorder.layerOf(root));
                  // Preserve the renderer layer's constructor/bind pose before
                  // setupAnim mutates it.  Dance-focused recipes use this for
                  // clothing layers when the animated pose needs several axes
                  // that one RP Engine element cannot represent.
                  mo.add("bindTree",tree(root));
                  mo.addProperty("setupAnim",setupAnim(model,state));
                  mo.add("tree",tree(root));
                  models.add(mo);
                }
              }
              layerInfo.add("models",models);layers.add(layerInfo);
            }
          }
          out.add("renderLayers",layers);
          // A compact state summary, useful for deterministic recipes.
          JsonObject defaults=new JsonObject();
          defaults.addProperty("isBaby",false);
          for(String name:List.of("isSheared","isJebSheep","isAngry","isSitting","isAggressive")){
            try{defaults.add(name,GSON.toJsonTree(field(state.getClass(),name).get(state)));}catch(Exception ignored){}
          }
          out.add("stateDefaults",defaults);
          out.addProperty("status","extracted");
          extracted++;
        }catch(Throwable t){
          Throwable cause=t instanceof InvocationTargetException?((InvocationTargetException)t).getTargetException():t;
          out.addProperty("status","failed");
          out.addProperty("error",String.valueOf(cause));
          JsonArray trace=new JsonArray();
          for(int i=0;i<Math.min(8,cause.getStackTrace().length);i++)trace.add(cause.getStackTrace()[i].toString());
          out.add("trace",trace);
          failed++;
        }
        Files.writeString(output.resolve("entities").resolve(path+".json"),GSON.toJson(out)+"\n");
      }
      JsonObject summary=new JsonObject();
      summary.addProperty("minecraftVersion",Class.forName("net.minecraft.SharedConstants").getMethod("getCurrentVersion").invoke(null).toString());
      summary.addProperty("entityTypeCount",BuiltInRegistries.ENTITY_TYPE.size());
      summary.addProperty("layerDefinitionCount",definitions.size());
      summary.addProperty("candidateCount",candidates);
      summary.addProperty("extractedCount",extracted);
      summary.addProperty("failedCount",failed);
      JsonArray layerIds=new JsonArray();
      definitions.keySet().stream().map(l->l.model()+"#"+l.layer()).sorted().forEach(layerIds::add);
      summary.add("layerDefinitions",layerIds);
      summary.add("entities",inventory);
      Files.writeString(output.resolve("inventory.json"),GSON.toJson(summary)+"\n");
      System.out.println("inventory="+inventory.size()+" candidates="+candidates+" extracted="+extracted+" failed="+failed+" layers="+definitions.size());
    }
  }
}
