package extractor;

import com.google.gson.*;
import java.nio.file.*;
import java.lang.reflect.Field;
import java.util.*;
import net.minecraft.client.renderer.entity.layers.VillagerProfessionLayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.client.renderer.entity.state.SheepRenderState;
import net.minecraft.world.entity.animal.fish.TropicalFish;
import net.minecraft.world.entity.animal.equine.Llama;
import net.minecraft.world.entity.animal.panda.Panda;
import net.minecraft.world.entity.animal.rabbit.Rabbit;
import net.minecraft.world.item.DyeColor;

/** Emits official variant enums/colours so no texture or colour is guessed. */
public final class VariantData {
  static final Gson GSON=new GsonBuilder().setPrettyPrinting().create();
  public static void main(String[] args)throws Exception{
    Class.forName("net.minecraft.SharedConstants").getMethod("tryDetectVersion").invoke(null);
    Class.forName("net.minecraft.server.Bootstrap").getMethod("bootStrap").invoke(null);
    JsonObject out=new JsonObject();
    JsonArray dyes=new JsonArray();
    for(DyeColor color:DyeColor.values()){
      JsonObject o=new JsonObject();o.addProperty("name",color.getName());
      o.addProperty("argb",color.getTextureDiffuseColor());dyes.add(o);
    }
    out.add("dyeColors",dyes);
    SheepRenderState sheep=new SheepRenderState();JsonArray wools=new JsonArray();
    for(DyeColor color:DyeColor.values()){
      sheep.woolColor=color;JsonObject o=new JsonObject();o.addProperty("name",color.getName());
      o.addProperty("argb",sheep.getWoolColor());wools.add(o);
    }
    out.add("sheepWoolColors",wools);
    JsonArray patterns=new JsonArray();
    for(TropicalFish.Pattern pattern:TropicalFish.Pattern.values()){
      JsonObject o=new JsonObject();o.addProperty("name",pattern.getSerializedName());
      o.addProperty("base",pattern.base().name());o.addProperty("packedId",pattern.getPackedId());patterns.add(o);
    }
    out.add("fishPatterns",patterns);
    out.addProperty("fishDefaultPattern",TropicalFish.DEFAULT_VARIANT.pattern().getSerializedName());
    out.addProperty("fishDefaultBaseColor",TropicalFish.DEFAULT_VARIANT.baseColor().getName());
    out.addProperty("fishDefaultPatternColor",TropicalFish.DEFAULT_VARIANT.patternColor().getName());
    JsonArray rabbits=new JsonArray();for(Rabbit.Variant v:Rabbit.Variant.values())rabbits.add(v.getSerializedName());out.add("rabbitVariants",rabbits);
    JsonArray llamas=new JsonArray();for(Llama.Variant v:Llama.Variant.values())llamas.add(v.getSerializedName());out.add("llamaColors",llamas);
    JsonArray pandas=new JsonArray();for(Panda.Gene v:Panda.Gene.values())pandas.add(v.getSerializedName());out.add("pandaGenes",pandas);
    JsonArray villagerTypes=new JsonArray();
    BuiltInRegistries.VILLAGER_TYPE.keySet().stream().sorted(Comparator.comparing(Object::toString))
        .forEach(id->villagerTypes.add(id.toString()));
    out.add("villagerTypes",villagerTypes);
    JsonArray villagerProfessions=new JsonArray();
    BuiltInRegistries.VILLAGER_PROFESSION.keySet().stream().sorted(Comparator.comparing(Object::toString))
        .forEach(id->villagerProfessions.add(id.toString()));
    out.add("villagerProfessions",villagerProfessions);
    Field locationsField=VillagerProfessionLayer.class.getDeclaredField("LEVEL_LOCATIONS");
    locationsField.setAccessible(true);
    @SuppressWarnings("unchecked") Map<Integer,Identifier> locations=(Map<Integer,Identifier>)locationsField.get(null);
    JsonArray villagerLevels=new JsonArray();
    locations.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(entry->{
      JsonObject o=new JsonObject();o.addProperty("level",entry.getKey());o.addProperty("texture",entry.getValue().toString());
      villagerLevels.add(o);
    });
    out.add("villagerLevels",villagerLevels);
    Files.writeString(Path.of(args[0]),GSON.toJson(out)+"\n");
    System.out.println("variant data: "+patterns.size()+" fish patterns, "+dyes.size()+" dye colours, "+villagerTypes.size()+" villager types, "+villagerProfessions.size()+" villager professions");
  }
}
