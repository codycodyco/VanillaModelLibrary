package extractor;
import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import java.io.*;
import javax.imageio.ImageIO;
public final class TextureCheck {
 public static void main(String[] args)throws Exception {
  JsonObject model=JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonObject();
  String mob=model.get("name").getAsString().replace("_adult","");
  try(ZipFile z=new ZipFile(args[1])) {
   for(JsonElement raw:model.getAsJsonArray("textures")) {
    JsonObject t=raw.getAsJsonObject();String name=t.get("name").getAsString();
    byte[] original=z.getInputStream(z.getEntry("assets/minecraft/textures/entity/"+mob+"/"+name)).readAllBytes();
    byte[] embedded=Base64.getDecoder().decode(t.get("source").getAsString().split(",",2)[1]);
    var source=ImageIO.read(new ByteArrayInputStream(original));var image=ImageIO.read(new ByteArrayInputStream(embedded));
    if(source.getWidth()!=image.getWidth()||source.getHeight()!=image.getHeight())throw new AssertionError("PNG dimensions changed");
    if(!name.equals("sheep_wool.png")) {if(!Arrays.equals(original,embedded))throw new AssertionError("Official PNG bytes changed");}
    else {
     int color=JsonParser.parseString(Files.readString(Path.of(args[2],"sheep-color.json"))).getAsJsonObject().get("argb").getAsInt();
     for(int y=0;y<image.getHeight();y++)for(int x=0;x<image.getWidth();x++) {
      int a=source.getRGB(x,y),b=image.getRGB(x,y);if((a>>>24)!=(b>>>24))throw new AssertionError("Alpha changed");
      for(int shift:new int[]{0,8,16})if(Math.abs(((b>>>shift)&255)-((a>>>shift)&255)*((color>>>shift)&255)/255d)>0.500001)throw new AssertionError("Tint mismatch");
     }
    }
   }
  }
  System.out.println("PASS official PNG identity / tint / alpha: "+mob);
 }
}
