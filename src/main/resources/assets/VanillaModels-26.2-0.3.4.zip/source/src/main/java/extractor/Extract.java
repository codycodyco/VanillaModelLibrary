package extractor;

import com.google.gson.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

/** Reflective reader of verified official named bytecode. No geometry constants. */
public final class Extract {
    static Object read(Object o, String name) throws Exception {
        Field f=o.getClass().getDeclaredField(name); f.setAccessible(true); return f.get(o);
    }
    static Object call(Object o,String method) throws Exception { return o.getClass().getMethod(method).invoke(o); }
    static JsonElement tree(Object p) throws Exception {
        JsonObject out=new JsonObject();
        for(String f:List.of("x","y","z","xRot","yRot","zRot","xScale","yScale","zScale","visible","skipDraw"))
            out.add(f,new Gson().toJsonTree(read(p,f)));
        JsonArray cubes=new JsonArray();
        for(Object c:(List<?>)read(p,"cubes")) {
            JsonArray faces=new JsonArray();
            for(Object face:(Object[])read(c,"polygons")) {
                JsonObject fo=new JsonObject(); JsonArray vertices=new JsonArray();
                for(Object v:(Object[])call(face,"vertices")) {
                    JsonArray a=new JsonArray();
                    for(String f:List.of("x","y","z","u","v")) a.add((Number)call(v,f));
                    vertices.add(a);
                }
                fo.add("vertices",vertices); JsonArray normal=new JsonArray();
                Object n=call(face,"normal"); for(String f:List.of("x","y","z")) normal.add((Number)call(n,f));
                fo.add("normal",normal); faces.add(fo);
            }
            cubes.add(faces);
        }
        out.add("cubes",cubes); JsonObject children=new JsonObject();
        Map<?,?> map=(Map<?,?>)read(p,"children");
        for(String key:map.keySet().stream().map(Object::toString).sorted().toList()) children.add(key,tree(map.get(key)));
        out.add("children",children); return out;
    }
    public static void main(String[] args) throws Exception {
        String selected=args[0]; Path output=Path.of(args[1]); Files.createDirectories(output);
        Class.forName("net.minecraft.SharedConstants").getMethod("tryDetectVersion").invoke(null);
        Class.forName("net.minecraft.server.Bootstrap").getMethod("bootStrap").invoke(null);
        Map<?,?> layers=(Map<?,?>)Class.forName("net.minecraft.client.model.geom.LayerDefinitions").getMethod("createRoots").invoke(null);
        JsonObject out=new JsonObject();
        for(var e:layers.entrySet()) {
            String id=call(e.getKey(),"model")+"#"+call(e.getKey(),"layer");
            if(e.getKey().equals(Class.forName("net.minecraft.client.model.geom.ModelLayers").getField(selected.toUpperCase(Locale.ROOT)).get(null))) {
                Object root=call(e.getValue(),"bakeRoot");
                String[] recipe=switch(selected) {
                    case "cow" -> new String[]{"animal.cow.CowModel","LivingEntityRenderState"};
                    case "pig" -> new String[]{"animal.pig.PigModel","LivingEntityRenderState"};
                    case "sheep" -> new String[]{"animal.sheep.SheepModel","SheepRenderState"};
                    case "sheep_wool" -> new String[]{"animal.sheep.SheepFurModel","SheepRenderState"};
                    case "chicken" -> new String[]{"animal.chicken.AdultChickenModel","ChickenRenderState"};
                    case "zombie" -> new String[]{"monster.zombie.ZombieModel","ZombieRenderState"};
                    default -> throw new IllegalArgumentException("Unsupported layer: "+selected);
                };
                Class<?> model=Class.forName("net.minecraft.client.model."+recipe[0]);
                Class<?> state=Class.forName("net.minecraft.client.renderer.entity.state."+recipe[1]);
                Object instance=model.getConstructor(root.getClass()).newInstance(root);
                Object standing=state.getConstructor().newInstance();
                model.getMethod("setupAnim",state).invoke(instance,standing);
                if(selected.equals("sheep_wool")) {
                    int color=(Integer)state.getMethod("getWoolColor").invoke(standing);
                    Files.writeString(output.resolve("sheep-color.json"),"{\"argb\":"+color+"}\n");
                }
                out.add(id,tree(root));
            }
        }
        if(out.size()!=1) throw new IllegalArgumentException("Expected exactly one layer: "+selected+"; available="+layers.keySet());
        Gson gson=new GsonBuilder().setPrettyPrinting().create();
        Files.writeString(output.resolve(selected+".json"),gson.toJson(out)+"\n");
        JsonObject corners=new JsonObject();
        Class<?> fi=Class.forName("net.minecraft.client.renderer.FaceInfo");
        for(Object f:(Object[])fi.getMethod("values").invoke(null)) {
            JsonArray vs=new JsonArray();
            for(int i=0;i<4;i++) {
                Object v=fi.getMethod("getVertexInfo",int.class).invoke(f,i); JsonArray a=new JsonArray();
                for(String axis:List.of("xFace","yFace","zFace")) a.add(call(v,axis).toString().startsWith("MAX")?1:0);
                vs.add(a);
            }
            corners.add(f.toString().toLowerCase(Locale.ROOT),vs);
        }
        Class<?> uv=Class.forName("net.minecraft.client.resources.model.cuboid.CuboidFace$UVs");
        Object unit=uv.getConstructor(float.class,float.class,float.class,float.class).newInstance(0f,0f,1f,1f);
        JsonArray uvCorners=new JsonArray();
        for(int i=0;i<4;i++) {JsonArray a=new JsonArray(); for(String m:List.of("getVertexU","getVertexV")) a.add((Number)uv.getMethod(m,int.class).invoke(unit,i)); uvCorners.add(a);}
        corners.add("uv",uvCorners); Files.writeString(output.resolve("face-layout.json"),gson.toJson(corners)+"\n");
        System.out.println("Extracted "+selected);
    }
}
