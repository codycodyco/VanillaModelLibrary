package extractor;
import com.google.gson.*;
import java.nio.file.*;
import java.util.zip.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
public final class Tint {
 public static void main(String[] args)throws Exception {
  int color=JsonParser.parseString(Files.readString(Path.of(args[1],"sheep-color.json"))).getAsJsonObject().get("argb").getAsInt();
  try(ZipFile z=new ZipFile(args[0])) {
   BufferedImage source=ImageIO.read(z.getInputStream(z.getEntry("assets/minecraft/textures/entity/sheep/sheep_wool.png")));
   BufferedImage target=new BufferedImage(source.getWidth(),source.getHeight(),BufferedImage.TYPE_INT_ARGB);
   for(int y=0;y<source.getHeight();y++)for(int x=0;x<source.getWidth();x++) {
    int pixel=source.getRGB(x,y),out=pixel&0xff000000;
    for(int shift:new int[]{0,8,16})out|=Math.round(((pixel>>>shift)&255)*((color>>>shift)&255)/255f)<<shift;
    target.setRGB(x,y,out);
   }
   ImageIO.write(target,"png",Path.of(args[1],"sheep_wool_tinted.png").toFile());
   System.out.println("Baked official sheep tint: "+Integer.toHexString(color));
  }
 }
}
