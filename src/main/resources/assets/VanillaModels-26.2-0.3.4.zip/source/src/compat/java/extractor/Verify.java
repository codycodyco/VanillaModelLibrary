package extractor;

import ai.resourcepack.engine.core.item.BbModel;
import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
import java.io.*;
import javax.imageio.ImageIO;
import org.joml.*;

/**
 * Independent verification of one generated .bbmodel.
 *
 * 1. The pinned upstream BbModel.convert must preserve every cube, from/to,
 *    allowed element rotation, face rotation and texture slot.  The converter
 *    rounds coordinates/UVs to 0.01 model units; that exact rounding is
 *    predicted here, not waved through.
 * 2. Every official source vertex and UV is compared with the emitted box
 *    after inverting the emitted element rotation.  Faces are identified by
 *    geometry, not by trusting the converter's face choice, so zero-thickness
 *    (degenerate) cubes and mirrored/cardinal orientations are checked too.
 * 3. No source cube, face, texture slot or element may be silently missing.
 */
public final class Verify {
  static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
  static JsonObject json(Path p)throws Exception{return JsonParser.parseString(Files.readString(p)).getAsJsonObject();}
  static float[] arr(JsonArray a){float[] r=new float[a.size()];for(int i=0;i<r.length;i++)r[i]=a.get(i).getAsFloat();return r;}
  static float num(JsonObject o,String k,float d){return o.has(k)?o.get(k).getAsFloat():d;}
  static float round2(float v){return java.lang.Math.round(v*100f)/100f;}
  static boolean close(float a,float b,float eps){return java.lang.Math.abs(a-b)<=eps;}
  static boolean close(float[] a,float[] b,float eps){if(a.length!=b.length)return false;for(int i=0;i<a.length;i++)if(!close(a[i],b[i],eps))return false;return true;}

  static Matrix4f partMatrix(JsonObject p){
    return new Matrix4f().translate(num(p,"x",0),num(p,"y",0),num(p,"z",0))
      .rotateZYX(num(p,"zRot",0),num(p,"yRot",0),num(p,"xRot",0))
      .scale(num(p,"xScale",1),num(p,"yScale",1),num(p,"zScale",1));
  }
  static Matrix4f delivery(){return new Matrix4f().translate(8f,17.6f,8f).scale(-0.4f,-0.4f,0.4f);}
  static Matrix4f elementRotation(JsonObject e){
    if(!e.has("rotation"))return new Matrix4f();
    JsonObject r=e.getAsJsonObject("rotation");float[] o=arr(r.getAsJsonArray("origin"));
    String axis=r.get("axis").getAsString();float angle=(float)java.lang.Math.toRadians(r.get("angle").getAsFloat());
    Vector3f a=switch(axis){case "x"->new Vector3f(1,0,0);case "y"->new Vector3f(0,1,0);default->new Vector3f(0,0,1);};
    return new Matrix4f().translate(o[0],o[1],o[2]).rotate(angle,a.x,a.y,a.z).translate(-o[0],-o[1],-o[2]);
  }
  static float[] transform(Matrix4f m,float[] v){Vector3f p=m.transformPosition(new Vector3f(v[0],v[1],v[2]));return new float[]{p.x,p.y,p.z};}

  static int cubes=0,faces=0,vertices=0;
  static int slotOf(JsonObject face){
    JsonElement t=face.get("texture");
    if(t.getAsJsonPrimitive().isNumber())return t.getAsInt();
    String s=t.getAsString();
    return s.startsWith("#")?Integer.parseInt(s.substring(1)):Integer.parseInt(s);
  }
  static List<float[]> expectedPairs(JsonObject dest,JsonObject layout,String face,float[] frm,float[] to,float[] texSize){
    float[] uv=arr(dest.getAsJsonArray("uv"));int rotation=dest.has("rotation")?dest.get("rotation").getAsInt()/90:0;
    List<float[]> out=new ArrayList<>();
    for(int i=0;i<4;i++){
      float[] bits=arr(layout.getAsJsonArray(face).get(i).getAsJsonArray());
      float[] pos=new float[3];for(int j=0;j<3;j++)pos[j]=bits[j]==0?frm[j]:to[j];
      float[] ubits=arr(layout.getAsJsonArray("uv").get((i+rotation)%4).getAsJsonArray());
      float[] euv={(uv[0]+(uv[2]-uv[0])*ubits[0])*texSize[0]/16f,(uv[1]+(uv[3]-uv[1])*ubits[1])*texSize[1]/16f};
      out.add(new float[]{pos[0],pos[1],pos[2],euv[0],euv[1]});
    }
    return out;
  }
  static boolean assign(List<float[]> source,List<float[]> expected,boolean[] used,int index){
    if(index==source.size()){for(boolean u:used)if(!u)return false;return true;}
    float[] s=source.get(index);
    for(int i=0;i<expected.size();i++){
      if(used[i])continue;float[] e=expected.get(i);
      if(close(s[0],e[0],0.008f)&&close(s[1],e[1],0.008f)&&close(s[2],e[2],0.008f)
        &&close(s[3],e[3],0.12f)&&close(s[4],e[4],0.12f)){
        used[i]=true;
        if(assign(source,expected,used,index+1))return true;
        used[i]=false;
      }
    }
    return false;
  }
  static boolean faceMatches(List<float[]> source,List<float[]> expected){
    return assign(source,expected,new boolean[expected.size()],0);
  }

  static void walk(JsonObject part,Matrix4f parent,String layer,String path,Map<String,JsonObject> elements,
                   JsonObject layout,float[] texSize,Map<String,Integer> expectedSlot,Set<String> seen){
    Matrix4f local=new Matrix4f(parent).mul(partMatrix(part));
    if(part.has("visible")&&!part.get("visible").getAsBoolean())return;
    if(!part.get("skipDraw").getAsBoolean()){
      JsonArray cs=part.getAsJsonArray("cubes");
      for(int c=0;c<cs.size();c++){
        String name=layer+"/"+path+"/"+c;JsonObject e=elements.remove(name);check(e!=null,"Missing cube "+name);
        cubes++;
        float[] frm=arr(e.getAsJsonArray("from")),to=arr(e.getAsJsonArray("to"));
        Matrix4f rot=elementRotation(e);Matrix4f invRot=new Matrix4f(rot).invert();
        Matrix4f full=new Matrix4f(delivery()).mul(local);
        JsonObject destFaces=e.getAsJsonObject("faces");
        check(destFaces.size()==cs.get(c).getAsJsonArray().size(),"Lost faces "+name);
        Set<String> usedDest=new HashSet<>();Integer wantSlot=expectedSlot.get(layer);
        for(JsonElement raw:cs.get(c).getAsJsonArray()){
          JsonObject face=raw.getAsJsonObject();faces++;
          List<float[]> source=new ArrayList<>();
          for(JsonElement vr:face.getAsJsonArray("vertices")){
            float[] v=arr(vr.getAsJsonArray());
            float[] q=transform(invRot,transform(full,v));
            source.add(new float[]{q[0],q[1],q[2],v[3]*texSize[0],v[4]*texSize[1]});
          }
          String matched=null;
          for(var de:destFaces.entrySet()){
            if(usedDest.contains(de.getKey()))continue;
            JsonObject dest=de.getValue().getAsJsonObject();
            if(wantSlot!=null&&slotOf(dest)!=wantSlot)continue;
            if(faceMatches(source,expectedPairs(dest,layout,de.getKey(),frm,to,texSize))){matched=de.getKey();break;}
          }
          check(matched!=null,"Geometry/UV mismatch "+name+" face "+faces);
          usedDest.add(matched);vertices+=4;
        }
        check(usedDest.size()==destFaces.size(),"Unmatched emitted face "+name);
      }
    }
    for(var child:part.getAsJsonObject("children").entrySet()){
      walk(child.getValue().getAsJsonObject(),local,layer,path+"/"+child.getKey(),elements,layout,texSize,expectedSlot,seen);
    }
  }

  public static void main(String[] args)throws Exception{
    Path file=Path.of(args[0]),raw=Path.of(args[1]);JsonObject project=json(file);
    check(!project.has("animations"),"Animations forbidden");
    for(JsonElement e:project.getAsJsonArray("elements")){
      JsonObject o=e.getAsJsonObject();
      check(o.has("type")&&o.get("type").getAsString().equals("cube"),"Mesh/unknown element forbidden");
      if(o.has("rotation")){
        JsonObject r=o.getAsJsonObject("rotation");float a=r.get("angle").getAsFloat();
        check(java.lang.Math.abs(a)==22.5f||java.lang.Math.abs(a)==45f,"Rotation angle not representable");
        String axis=r.get("axis").getAsString();check(axis.equals("x")||axis.equals("y")||axis.equals("z"),"Bad rotation axis");
      }
    }

    var result=BbModel.convert(Files.readAllBytes(file),"vanillamobs",file.getFileName().toString().replace(".bbmodel","")).orElseThrow();
    JsonArray in=project.getAsJsonArray("elements"),out=result.model().getAsJsonArray("elements");
    check(in.size()==out.size(),"Upstream conversion changed cube count");
    JsonArray textures=project.getAsJsonArray("textures");
    for(int i=0;i<in.size();i++){
      JsonObject a=in.get(i).getAsJsonObject(),b=out.get(i).getAsJsonObject();
      float[] af=arr(a.getAsJsonArray("from")),bf=arr(b.getAsJsonArray("from"));
      float[] at=arr(a.getAsJsonArray("to")),bt=arr(b.getAsJsonArray("to"));
      for(int j=0;j<3;j++){check(close(bf[j],round2(af[j]),0.0001f),"Upstream changed from");check(close(bt[j],round2(at[j]),0.0001f),"Upstream changed to");}
      JsonObject ar=a.has("rotation")?a.getAsJsonObject("rotation"):null,br=b.has("rotation")?b.getAsJsonObject("rotation"):null;
      check((ar==null)==(br==null),"Upstream changed rotation presence");
      if(ar!=null){
        check(ar.get("axis").getAsString().equals(br.get("axis").getAsString()),"Upstream changed rotation axis");
        check(close(ar.get("angle").getAsFloat(),br.get("angle").getAsFloat(),0.0001f),"Upstream changed rotation angle");
        float[] ao=arr(ar.getAsJsonArray("origin")),bo=arr(br.getAsJsonArray("origin"));
        for(int j=0;j<3;j++)check(close(bo[j],round2(ao[j]),0.0001f),"Upstream changed rotation origin");
      }
      JsonObject afFaces=a.getAsJsonObject("faces"),bfFaces=b.getAsJsonObject("faces");
      check(afFaces.keySet().equals(bfFaces.keySet()),"Upstream changed face set");
      for(String k:afFaces.keySet()){
        JsonObject x=afFaces.getAsJsonObject(k),y=bfFaces.getAsJsonObject(k);
        int slot=x.get("texture").getAsInt();JsonObject tex=textures.get(slot).getAsJsonObject();
        float w=num(tex,"uv_width",16),h=num(tex,"uv_height",16);
        float[] xu=arr(x.getAsJsonArray("uv")),yu=arr(y.getAsJsonArray("uv"));
        float[] expected={round2(xu[0]*16/w),round2(xu[1]*16/h),round2(xu[2]*16/w),round2(xu[3]*16/h)};
        check(close(yu,expected,0.0001f),"Upstream changed UV");
        int xr=x.has("rotation")?x.get("rotation").getAsInt()/90:0,yr=y.has("rotation")?y.get("rotation").getAsInt()/90:0;
        check(xr==yr,"Upstream changed face rotation");
      }
    }
    Set<String> slots=result.model().getAsJsonObject("textures").keySet();
    for(JsonElement e:out)for(JsonElement f:e.getAsJsonObject().getAsJsonObject("faces").asMap().values())
      check(slots.contains(f.getAsJsonObject().get("texture").getAsString().substring(1)),"Bad texture reference");
    for(byte[] png:result.textures().values()){var image=ImageIO.read(new ByteArrayInputStream(png));check(image!=null&&image.getWidth()>0,"PNG decode failed");}

    JsonObject layout=json(raw.resolve("face-layout.json"));
    Map<String,Integer> slotByName=new HashMap<>();
    for(int i=0;i<textures.size();i++)slotByName.put(textures.get(i).getAsJsonObject().get("name").getAsString(),i);
    Map<String,Integer> expectedSlot=new HashMap<>();
    if(project.has("layer_textures")){
      for(var e:project.getAsJsonObject("layer_textures").entrySet()){
        Integer slot=slotByName.get(e.getValue().getAsString());check(slot!=null,"Unknown layer texture "+e.getValue());
        expectedSlot.put(e.getKey(),slot);
      }
    }
    Map<String,JsonObject> elements=new HashMap<>();
    for(JsonElement e:out)elements.put(e.getAsJsonObject().get("name").getAsString(),e.getAsJsonObject());
    Set<String> layerNames=new TreeSet<>();
    for(JsonElement e:in)layerNames.add(e.getAsJsonObject().get("name").getAsString().split("/")[0]);
    for(String layer:layerNames){
      JsonObject data=json(raw.resolve(layer+".json"));
      for(var entry:data.entrySet()){
        float w=1,h=1;Integer slot=expectedSlot.get(layer);
        if(slot!=null){JsonObject tex=textures.get(slot).getAsJsonObject();w=num(tex,"uv_width",1);h=num(tex,"uv_height",1);}
        walk(entry.getValue().getAsJsonObject(),new Matrix4f(),layer,"root",elements,layout,new float[]{w,h},expectedSlot,new HashSet<>());
      }
    }
    check(elements.isEmpty(),"Extra cubes in delivered model: "+elements.keySet());
    check(result.textures().size()==slotByName.size(),"Texture count changed");
    Path converted=file.resolveSibling(file.getFileName()+".converted.json");Files.writeString(converted,result.model().toString());
    System.out.println("PASS "+file.getFileName()+": "+cubes+" cubes, "+faces+" faces, "+vertices+" vertices + UVs, "+result.textures().size()+" decoded PNGs; actual upstream BbModel.convert");
  }
}
