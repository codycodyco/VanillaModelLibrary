import sys,pathlib,unittest,math
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from convert import matrix,mul,transform,eye,uv_face,Unsupported
class TransformTests(unittest.TestCase):
 def test_parent_rotation_carries_child_translation(self):
  actual=transform(mul(matrix({'zRot':math.pi/2,'x':10}),matrix({'x':2,'y':3})),[1,0,0])
  for a,b in zip(actual,[7,3,0]): self.assertAlmostEqual(a,b)
 def test_zyx_order(self):
  actual=transform(matrix({'xRot':math.pi/2,'yRot':math.pi/2,'zRot':math.pi/2}),[0,1,0])
  for a,b in zip(actual,[0,1,0]): self.assertAlmostEqual(a,b)
 def test_scale_before_translate(self):
  self.assertEqual(transform(matrix({'x':2,'xScale':3}),[4,0,0]),[14,0,0])
 def test_unsupported_rotation(self):
  with self.assertRaises(Unsupported):uv_face([], [1,1,0],[0]*3,[1]*3,{},16,16,0)
 def test_no_rectangle_fallback(self):
  layout={'east':[[1,0,0],[1,1,0],[1,1,1],[1,0,1]]}
  with self.assertRaises(Unsupported):uv_face([([1,0,0],[0,0])],[1,0,0],[0]*3,[1]*3,layout,16,16,0)
if __name__=='__main__':unittest.main()
