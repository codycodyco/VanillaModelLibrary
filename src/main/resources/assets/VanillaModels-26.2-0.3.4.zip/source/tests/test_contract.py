import unittest,pathlib,sys,json,tempfile,hashlib,copy
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from validate import schema
class SchemaTests(unittest.TestCase):
 def test_reject_boolean_schema_version(self):
  with self.assertRaises(AssertionError):schema(True,{'type':'integer','const':1})
 def test_reject_missing_display(self):
  s=json.loads((pathlib.Path(__file__).resolve().parents[1]/'schemas/catalog.schema.json').read_text())
  with self.assertRaises(AssertionError):schema({'schema':1,'minecraftVersion':'26.2','namespace':'vanillamobs','models':[{}]*5},s)
 def test_reject_nonfinite(self):
  with self.assertRaises(AssertionError):schema(float('nan'),{'type':'number'})
 def test_reject_unrecognized_contract_fields(self):
  with self.assertRaises(AssertionError):schema({'schema':1,'extra':0},{'type':'object','properties':{'schema':{'const':1}},'additionalProperties':False})
if __name__=='__main__':unittest.main()
