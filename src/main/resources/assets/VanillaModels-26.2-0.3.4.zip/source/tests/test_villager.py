import copy,json,math,os,pathlib,sys,unittest,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from build_assets import load_recipes,base_conditions,apply_pose_override
from build_variants import tree_uv_rectangles
class VillagerPolicy(unittest.TestCase):
 def test_conditions_do_not_claim_other_professions_or_babies(self):
  c=base_conditions(load_recipes(),'villager')
  self.assertEqual((c['age'],c['variant'],c['profession'],c['professionLevel']),('adult','minecraft:plains','none',1))
  self.assertEqual(c['villagerType'],'plains')
 def test_vindicator_neutral(self):
  c=base_conditions(load_recipes(),'vindicator')
  self.assertFalse(c['aggressive']);self.assertEqual(c['heldItem'],'none')
 def test_villager_pose_override_is_exact_and_non_mutating(self):
  original={'children':{'arms':{'xRot':-0.75,'children':{}}}}
  snapshot=copy.deepcopy(original)
  adjusted,notes=apply_pose_override('minecraft:villager',original,load_recipes())
  self.assertEqual(original,snapshot)
  self.assertEqual(adjusted['children']['arms']['xRot'],-math.pi/4)
  self.assertIn('2.0281653652',notes[0])
 def test_uv_mask_uses_only_drawn_parts(self):
  face={'vertices':[[0,0,0,0.25,0.5],[0,0,0,0.5,0.5],[0,0,0,0.5,0.75],[0,0,0,0.25,0.75]]}
  tree={'cubes':[[face]],'children':{'hidden':{'visible':False,'cubes':[[{'vertices':[[0,0,0,0,0],[0,0,0,1,0],[0,0,0,1,1],[0,0,0,0,1]]}]],'children':{}}}}
  self.assertEqual(tree_uv_rectangles(tree,64,64),[[16,32,32,48]])
@unittest.skipUnless(os.environ.get('VANILLA_TEST_DIST'),'requires actual built artifacts')
class ActualVillagerAssets(unittest.TestCase):
 def test_two_registered_models(self):
  dist=pathlib.Path(os.environ['VANILLA_TEST_DIST'])
  cat=json.loads((dist/'catalog.json').read_text());records={m['modelId']:m for m in cat['models']}
  for name in ('vindicator_adult','villager_adult'):
   self.assertTrue(records['vanillamobs:'+name]['supported'])
   model=json.loads((dist/'content/vanillamobs/assets/models'/f'{name}.bbmodel').read_text())
   self.assertGreater(len(model['elements']),0)
   self.assertTrue(all(e['type']=='cube' for e in model['elements']))
   self.assertIn(f'model: {name}',(dist/'content/vanillamobs/items/mobs.yml').read_text())
  villager=json.loads((dist/'content/vanillamobs/assets/models/villager_adult.bbmodel').read_text())
  angles=[e.get('rotation',{}).get('angle') for e in villager['elements'] if e.get('rotation')]
  self.assertIn(45.0,[abs(angle) for angle in angles])
 def test_existing_models_preserved(self):
  old=ROOT/'VanillaModels-26.2-0.3.2.zip'
  if not old.exists():self.skipTest('previous release not supplied')
  dist=pathlib.Path(os.environ['VANILLA_TEST_DIST'])
  with zipfile.ZipFile(old) as z:
   for name in z.namelist():
    if name.startswith('dist/content/') and name.endswith('.bbmodel'):
     self.assertEqual(z.read(name),(dist/pathlib.PurePosixPath(name).relative_to('dist')).read_bytes(),name)
 def test_curated_profession_dance_set(self):
  dist=pathlib.Path(os.environ['VANILLA_TEST_DIST'])
  records=[m for m in json.loads((dist/'catalog.json').read_text())['models'] if m['entityType']=='VILLAGER' and m['supported']]
  professions={'armorer','butcher','cartographer','cleric','farmer','fisherman','fletcher','leatherworker','librarian','mason','nitwit','shepherd','toolsmith','weaponsmith'}
  actual={(m['conditions']['villagerType'],m['conditions']['profession'],m['conditions']['professionLevel']) for m in records}
  expected={('plains','none',1)}|{('plains',p,1) for p in professions}
  self.assertEqual(actual,expected);self.assertEqual(len(records),15)
  model_dir=dist/'content/vanillamobs/assets/models';items=(dist/'content/vanillamobs/items/mobs.yml').read_text()
  for m in records:
   name=m['modelId'].split(':')[1];model=json.loads((model_dir/(name+'.bbmodel')).read_text())
   self.assertEqual((len(model['elements']),len(model['textures'])),(11,1),name)
   self.assertIn(f'model: {name}',items)
