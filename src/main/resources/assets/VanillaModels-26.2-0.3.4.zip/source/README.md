# VanillaModelExtractor 0.3.4

真实 Minecraft Java **26.2** 原版非玩家生物静态模型提取器。只生成 RP Engine
资源，不实现 Paper 插件，不修改服务器。

## 实际结果（不是预估）

- 官方实体注册表：158 个 `EntityType`；候选生物（含注册为 MISC 的村民）：**87**。
- 官方模型层：**358** 个 `LayerDefinitions` 条目。
- `--all-defaults`：**50 / 87** 个生物生成基础外观并通过真实转换。
- `--all-variants`：在默认之上新增 **86** 个变体；总计 **136** 个可用模型。
- 未支持：**45** 个 catalog 记录（37 个默认实体 + 8 个变体），每个都有具体
  stage/reason；没有静默丢弃，也没有为 unsupported 注册 ITEM。
- 所有支持模型合计 **1,395** 个 cube、**8,370** 个面、**170** 个嵌入 PNG
  （唯一 PNG 133 个），`dist` 内容 **2,277,430** 字节。
- 0.3.3 的 124 个模型曾通过 Paper 26.2-134 + RP Engine 0.2.20 实测；0.3.4
  新增的 12 个舞蹈模型按本次要求未运行服务器验证，交由 DSH 验证。

默认阶段（0.2.0）单独数据：38 个模型、367 cube、2,202 面、42 PNG、
604,039 字节内容。变体阶段在其上扩展。

## 为什么还有 37 个默认实体不支持

RP Engine 的 `BbModel.convert` 只接受单轴 `0/±22.5/±45°` 的元素旋转，并把
`from/to` 与 UV 量化到 0.01。大量生物默认待机姿态含任意角度或多轴旋转：
僵尸手臂约 `x=-80°, y=-5.73°, z=5.73°`，狼/猫/马/恶魂等也有
非可表达姿态。对每个此类模型，catalog/report 记录具体失败的 cube 路径，
例如：

```
main/root/left_arm/0: Non-representable orientation:
RP Engine element rotations are single-axis 0/+-22.5/+-45 degrees
```

本项目拒绝把旋转吸附到最近角度、拒绝只导出身体而丢掉默认覆盖层。Ender Dragon 的
多纹理渲染和 Mooshroom 的方块蘑菇覆盖层同样被明确标为 unsupported。

`zombie_adult`（0.3.1 起）使用官方模型绑定姿态（手臂
下垂）导出为单个静态 ITEM。这是你明确接受的静态替换姿态，不是原版默认抬手
待机姿态；limitations 里已写明。

0.3.4 采用同一策略新增 spider、cave_spider、skeleton、stray、bogged、husk、
drowned、zombie_villager、wither_skeleton、piglin、piglin_brute 和
zombified_piglin。官方 cube、逐面 UV、纹理与可见覆盖层保留；蜘蛛腿只保留
官方 yaw，猪灵耳朵使用 22.5°，其余人形怪使用官方 bind pose。

村民（0.3.3）采用跳舞用精简集，共 **15** 款：成年平原无职业、nitwit，以及
13 种交易职业的等级 1 外观。官方 base → type → profession → profession_level
渲染顺序合成为单张 PNG，类型层按官方帽子元数据应用 `villager_no_hat` UV
遮罩。抱臂从官方 -42.9718346348° 调整为 RP Engine 可无损表达的 -45°；其他
生物群系服装和等级 2–5 徽章明确列为未覆盖。

## 支持范围

支持：牛/猪/羊/鸡、兔子、羊驼/商队羊驼、熊猫、北极熊、骆驼/骆驼尸壳、
嗅探兽、鱿鱼/发光鱿鱼、鹦鹉螺/僵尸鹦鹉螺、守卫者/远古守卫者、蜘蛛/洞穴蜘蛛、
骷髅/流浪者/沼骸/凋灵骷髅、尸壳/溺尸/僵尸村民、猪灵/猪灵蛮兵/僵尸猪灵、史莱姆/岩浆怪/
硫磺立方、蝙蝠、烈焰人、苦力怕、幻术师/唤魔者/掠夺者/卫道士、青蛙、鳕鱼/鲑鱼/
热带鱼、海龟、潜影贝、蝌蚪等；完整列表以 `dist/catalog.json` 为准。

变体覆盖：

- 幼年：14 个（兔子幼年与僵尸幼年因几何/旋转问题明确 unsupported）。
- 气候：牛/猪/鸡/青蛙的 warm/cold；僵尸鹦鹉螺 warm 因珊瑚旋转 unsupported。
- 羊毛颜色：15 种非白色 + 默认白色；剪毛；`jeb_` 动态彩虹明确 unsupported。
- 羊驼/商队羊驼颜色：white/brown/gray。
- 兔子：white/black/white_splotched/gold/salt/evil。
- 熊猫：lazy/worried/playful/brown/weak/aggressive。
- 热带鱼：12 种 pattern 的 small/large、white/white 组合；其他颜色组合未覆盖。
- 村民：平原成年无职业、nitwit，以及 armorer、butcher、cartographer、cleric、
  farmer、fisherman、fletcher、leatherworker、librarian、mason、shepherd、
  toolsmith、weaponsmith 的等级 1 跳舞模型。
- 每种外观使用确定性 `modelId`；未被精确覆盖的变体不会匹配默认条件。

## Ubuntu 一键构建

Mac 不需要 Java/Gradle。Ubuntu 需要 Python 3.10+、JDK 25、访问 Mojang/Gradle
的网络；缓存已存在时可离线。

```bash
export JAVA_HOME=/path/to/jdk-25
./scripts/ubuntu-build.sh /private/path/to/official-client.jar
```

脚本：校验官方 SHA-1 → Gradle 编译/单测 → 原始 cow 门禁 → 注册表全量抽取 →
默认+变体构建 → schema/哈希校验 → Paper/RP Engine 可选测试 → 两次确定性构建 →
`VanillaModels-26.2-0.3.4.zip`。

单独运行：

```bash
python3 scripts/build_assets.py --all-defaults dist
python3 scripts/build_variants.py dist
python3 scripts/validate.py dist
python3 scripts/package.py
```

## 私有交付

- 只安装 `dist/content/vanillamobs` 到 `plugins/RPEngine/content/vanillamobs`。
- 每个支持模型注册为 PAPER + 单 ItemDisplay；`catalog.json` 的 `display`
  使用 scale=2.5、offsetY=0.001、yawOffsetDegrees=180。
- **不要公开提交官方客户端 JAR 或完整提取素材。** `dist/`、`.cache/`、
  `build/`、ZIP 已被 `.gitignore` 排除；交付 ZIP 仅私下使用。
- RP Engine 默认可能上传资源；测试配置使用 `host.mode: none`。

## 已验证与未验证

已验证：官方 PNG 字节、官方顶点+UV 与真实 `BbModel.convert`；0.3.3 的 124 个
ITEM 曾通过 Paper bundle。0.3.4 按要求只生成和打包，没有重新运行服务器验证。

未验证：真实客户端视觉对照、ItemDisplay 在世界中的对齐/光照/透明边缘、
光影、Bedrock、其他 MC 版本、未列出的颜色组合和装备/动画。

细节见 `docs/ASSET_CONTRACT.md`、`docs/VERIFICATION.md`、`dist/report.json`。
