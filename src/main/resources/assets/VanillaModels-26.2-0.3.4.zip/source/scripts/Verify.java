package extractor;

import ai.resourcepack.engine.core.item.BbModel;
import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
import java.io.*;
import javax.imageio.ImageIO;
import org.joml.*;

/**
 * Independent verification of one generated .bbmodel.
 *
 * 1. The real pinned RP Engine BbModel.convert must produce exactly the same
 *    cube count, from/to boxes, allowed element rotations, face UVs and
 *    decodable PNGs.
 * 2. Every official source vertex, normal and UV is compared against the
 *    emitted box after inverting the emitted element rotation.  Degenerate
 *    (zero-thickness) cubes are compared as multisets of (position, UV).
 * 3. No source cube, face, texture slot or element may be silently missing.
 */
public final class Verify {
  static final Gson GSON=new Gson();
  static final float EPS=0.0002f;
  static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
  static JsonObject json(Path p)throws Exception{return JsonParser.parseString(Files.readString(p)).getAsJsonObject();}
  static float[] arr(JsonArray a){float[] r=new float[a.size()];for(int i=0;i<r.length;i++)r[i]=a.get(i).getAsFloat();return r;}
  static float num(JsonObject o,String k,float d){return o.has(k)?o.get(k).getAsFloat():d;}
  static boolean same(float a,float b){return Math.abs(a-b)<=EPS;}
  static boolean same(float[] a,float[] b){if(a.length!=b.length)return false;for(int i=0;i<a.length;i++)if(!same(a[i],b[i]))return false;return true;}

  static Matrix4f partMatrix(JsonObject p){
    Matrix4f m=new Matrix4f().translate(num(p,"x",0),num(p,"y",0),num(p,"z",0))
      .rotateZYX(num(p,"zRot",0),num(p,"yRot",0),num(p,"xRot",0))
      .scale(num(p,"xScale",1),num(p,"yScale",1),num(p,"zScale",1));
    return m;
  }
  static Matrix4f delivery(){return new Matrix4f().translate(8f,17.6f,8f).scale(-0.4f,-0.4f,0.4f);}
  static Matrix4f elementRotation(JsonObject e){
    if(!e.has("rotation"))return new Matrix4f();
    JsonObject r=e.getAsJsonObject("rotation");float[] o=arr(r.getAsJsonArray("origin"));
    String axis=r.get("axis").getAsString();float angle=(float)Math.toRadians(r.get("angle").getAsFloat());
    Vector3f a=switch(axis){case "x"->new Vector3f(1,0,0);case "y"->new Vector3f(0,1,0);default->new Vector3f(0,0,1);};
    return new Matrix4f().translate(o[0],o[1],o[2]).rotate(angle,a.x,a.y,a.z).translate(-o[0],-o[1],-o[2]);
  }
  static String faceOf(float[] n){
    int axis=0;for(int i=1;i<3;i++)if(Math.abs(n[i])>Math.abs(n[axis]))axis=i;
    check(Math.abs(Math.abs(n[axis])-1f)<0.01f,"Non-axis-aligned source normal");
    return new String[][]{{"west","east"},{"down","up"},{"north","south"}}[axis][n[axis]>0?1:0];
  }
  static float[] transform(Matrix4f m,float[] v){Vector3f p=m.transformPosition(new Vector3f(v[0],v[1],v[2]));return new float[]{p.x,p.y,p.z};}
  static float[] direction(Matrix4f m,float[] v){Vector3f p=m.transformDirection(new Vector3f(v[0],v[1],v[2]));return new float[]{p.x,p.y,p.z};}
  static boolean pairMatches(float[] p,float[] uv,float[] ep,float[] euv){
    return same(p,ep)&&same(uv[0],euv[0])&&same(uv[1],euv[1]);
  }

  static int cubes=0,faces=0,vertices=0;
  static void walk(JsonObject part,Matrix4f parent,String layer,String path,Map<String,JsonObject> elements,
                   JsonObject layout,float[] texSize,Map<String,Integer> expectedSlot,Set<String> seen){
    Matrix4f local=new Matrix4f(parent).mul(partMatrix(part));
    if(part.has("visible")&&!part.get("visible").getAsBoolean())return;
    if(!part.get("skipDraw").getAsBoolean()){
      JsonArray cs=part.getAsJsonArray("cubes");
      for(int c=0;c<cs.size();c++){
        String name=layer+"/"+path+"/"+c;JsonObject e=elements.remove(name);check(e!=null,"Missing cube "+name);
        check(!e.has("type")||e.get("type").getAsString().equals("cube"),"Non-cube element "+name);
        cubes++;
        float[] frm=arr(e.getAsJsonArray("from")),to=arr(e.getAsJsonArray("to"));
        Matrix4f rot=elementRotation(e);Matrix4f invRot=new Matrix4f(rot).invert();
        check(e.getAsJsonObject("faces").size()==cs.get(c).getAsJsonArray().size(),"Lost faces "+name);
        Integer wantSlot=expectedSlot.get(layer);
        for(JsonElement raw:cs.get(c).getAsJsonArray()){
          JsonObject face=raw.getAsJsonObject();faces++;
          float[] n=arr(face.getAsJsonArray("normal"));
          // source normal in delivery space, then into the unrotated box frame
          Matrix4f full=new Matrix4f(delivery()).mul(local);
          float[] dn=direction(full,n);float[] qn=direction(invRot,dn);
          String key=faceOf(qn);
          JsonObject dest=e.getAsJsonObject("faces").getAsJsonObject(key);check(dest!=null,"Missing face "+key+" in "+name);
          if(wantSlot!=null)check(dest.get("texture").getAsInt()==wantSlot,"Wrong texture slot "+name+"/"+key);
          float[] uv=arr(dest.getAsJsonArray("uv"));
          int rotation=dest.has("rotation")?dest.get("rotation").getAsInt()/90:0;
          List<float[]> expected=new ArrayList<>();
          for(int i=0;i<4;i++){
            float[] bits=arr(layout.getAsJsonArray(key).get(i).getAsJsonArray());
            float[] pos=new float[3];for(int j=0;j<3;j++)pos[j]=bits[j]==0?frm[j]:to[j];
            float[] ubits=arr(layout.getAsJsonArray("uv").get((i+rotation)%4).getAsJsonArray());
            float[] euv={uv[0]+(uv[2]-uv[0])*ubits[0],uv[1]+(uv[3]-uv[1])*ubits[1]};
            expected.add(new float[]{pos[0],pos[1],pos[2],euv[0],euv[1]});
          }
          boolean[] used=new boolean[4];
          for(JsonElement vr:face.getAsJsonArray("vertices")){
            float[] v=arr(vr.getAsJsonArray());
            float[] world=transform(full,v);
            float[] q=transform(invRot,world);
            float[] suv={v[3]*texSize[0],v[4]*texSize[1]};
            boolean found=false;
            for(int i=0;i<4;i++)if(!used[i]&&pairMatches(q,suv,new float[]{expected.get(i)[0],expected.get(i)[1],expected.get(i)[2]},new float[]{expected.get(i)[3],expected.get(i)[4]})){
              used[i]=true;found=true;vertices++;break;
            }
            check(found,"Geometry/UV mismatch "+name+"/"+key+" at "+Arrays.toString(q)+" uv="+Arrays.toString(suv));
          }
          for(int i=0;i<4;i++)check(used[i],"Unmatched emitted corner "+name+"/"+key);
        }
      }
    }
    for(var child:part.getAsJsonObject("children").entrySet()){
      walk(child.getValue().getAsJsonObject(),local,layer,path+"/"+child.getKey(),elements,layout,texSize,expectedSlot,seen);
    }
  }

  public static void main(String[] args)throws Exception{
    Path file=Path.of(args[0]),raw=Path.of(args[1]);JsonObject project=json(file);
    check(!project.has("animations"),"Animations forbidden");
    for(JsonElement e:project.getAsJsonArray("elements"))
      check(e.getAsJsonObject().has("type")&&e.getAsJsonObject().get("type").getAsString().equals("cube"),"Mesh/unknown element forbidden");

    var result=BbModel.convert(Files.readAllBytes(file),"vanillamobs",file.getFileName().toString().replace(".bbmodel","")).orElseThrow();
    JsonArray in=project.getAsJsonArray("elements"),out=result.model().getAsJsonArray("elements");
    check(in.size()==out.size(),"Upstream conversion changed cube count");
    for(int i=0;i<in.size();i++){
      JsonObject a=in.get(i).getAsJsonObject(),b=out.get(i).getAsJsonObject();
      check(same(arr(a.getAsJsonArray("from")),arr(b.getAsJsonArray("from"))),"Upstream changed from");
      check(same(arr(a.getAsJsonArray("to")),arr(b.getAsJsonArray("to"))),"Upstream changed to");
      JsonObject ar=a.has("rotation")?a.getAsJsonObject("rotation"):null,br=b.has("rotation")?b.getAsJsonObject("rotation"):null;
      check((ar==null)==(br==null),"Upstream changed rotation presence");
      if(ar!=null){
        check(ar.get("axis").getAsString().equals(br.get("axis").getAsString()),"Upstream changed rotation axis");
        check(same(ar.get("angle").getAsFloat(),br.get("angle").getAsFloat()),"Upstream changed rotation angle");
        check(same(arr(ar.getAsJsonArray("origin")),arr(br.getAsJsonArray("origin"))),"Upstream changed rotation origin");
      }
      JsonObject af=a.getAsJsonObject("faces"),bf=b.getAsJsonObject("faces");
      check(af.keySet().equals(bf.keySet()),"Upstream changed face set");
      JsonArray textures=project.getAsJsonArray("textures");
      for(String k:af.keySet()){
        JsonObject x=af.getAsJsonObject(k),y=bf.getAsJsonObject(k);
        int slot=x.get("texture").getAsInt();JsonObject tex=textures.get(slot).getAsJsonObject();
        float w=num(tex,"uv_width",16),h=num(tex,"uv_height",16);
        float[] xu=arr(x.getAsJsonArray("uv")),yu=arr(y.getAsJsonArray("uv"));
        check(same(xu[0]*16/w,yu[0])&&same(xu[1]*16/h,yu[1])&&same(xu[2]*16/w,yu[2])&&same(xu[3]*16/h,yu[3]),"Upstream changed UV");
        int xr=x.has("rotation")?x.get("rotation").getAsInt()/90:0,yr=y.has("rotation")?y.get("rotation").getAsInt()/90:0;
        check(xr==yr,"Upstream changed face rotation");
      }
    }
    Set<String> slots=result.model().getAsJsonObject("textures").keySet();
    for(JsonElement e:out){for(JsonElement f:e.getAsJsonObject().getAsJsonObject("faces").asMap().values())
      check(slots.contains(f.getAsJsonObject().get("texture").getAsString().substring(1)),"Bad texture reference");}
    for(byte[] png:result.textures().values()){var image=ImageIO.read(new ByteArrayInputStream(png));check(image!=null&&image.getWidth()>0,"PNG decode failed");}

    JsonObject layout=json(raw.resolve("face-layout.json"));
    Map<String,Integer> slotByName=new HashMap<>();
    JsonArray inTex=project.getAsJsonArray("textures");
    for(int i=0;i<inTex.size();i++)slotByName.put(inTex.get(i).getAsJsonObject().get("name").getAsString(),i);
    Map<String,Integer> expectedSlot=new HashMap<>();
    if(project.has("layer_textures")){
      for(var e:project.getAsJsonObject("layer_textures").entrySet()){
        Integer slot=slotByName.get(e.getValue().getAsString());check(slot!=null,"Unknown layer texture "+e.getValue());
        expectedSlot.put(e.getKey(),slot);
      }
    }
    Map<String,JsonObject> elements=new HashMap<>();
    for(JsonElement e:out)elements.put(e.getAsJsonObject().get("name").getAsString(),e.getAsJsonObject());
    Set<String> layerNames=new TreeSet<>();
    for(JsonElement e:in)layerNames.add(e.getAsJsonObject().get("name").getAsString().split("/")[0]);
    for(String layer:layerNames){
      JsonObject data=json(raw.resolve(layer+".json"));
      for(var entry:data.entrySet()){
        JsonObject root=entry.getValue().getAsJsonObject();
        float w=1,h=1;Integer slot=expectedSlot.get(layer);
        if(slot!=null){JsonObject tex=inTex.get(slot).getAsJsonObject();w=num(tex,"uv_width",1);h=num(tex,"uv_height",1);}
        walk(root,new Matrix4f(),layer,"root",elements,layout,new float[]{w,h},expectedSlot,new HashSet<>());
      }
    }
    check(elements.isEmpty(),"Extra cubes in delivered model: "+elements.keySet());
    check(result.textures().size()==slotByName.size(),"Texture count changed");
    Path converted=file.resolveSibling(file.getFileName()+".converted.json");Files.writeString(converted,result.model().toString());
    System.out.println("PASS "+file.getFileName()+": "+cubes+" cubes, "+faces+" faces, "+vertices+" vertices + UVs, "+result.textures().size()+" decoded PNGs; actual upstream BbModel.convert");
  }
}
