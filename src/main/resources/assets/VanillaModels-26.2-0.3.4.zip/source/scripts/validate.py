#!/usr/bin/env python3
"""Strict schema-1 validation of the generated private delivery."""
import json,pathlib,re,hashlib,sys,math
ROOT=pathlib.Path(__file__).resolve().parents[1]
def schema(value,s,path='$'):
 types={'object':dict,'array':list,'string':str,'integer':int,'number':(int,float),'boolean':bool}
 if 'type' in s:
  assert isinstance(value,types[s['type']]) and not (s['type'] in ('integer','number') and isinstance(value,bool)),path+' type'
 if 'const' in s:assert value==s['const'],path+' const'
 if 'enum' in s:assert value in s['enum'],path+' enum'
 if 'pattern' in s:assert re.fullmatch(s['pattern'],value),path+' pattern'
 if isinstance(value,(int,float)):assert math.isfinite(value),path+' finite'
 if isinstance(value,dict):
  assert set(s.get('required',[]))<=value.keys(),path+' missing keys'
  if s.get('additionalProperties') is False:assert value.keys()<=s.get('properties',{}).keys(),path+' unexpected keys'
  for k,v in value.items():
   if k in s.get('properties',{}):schema(v,s['properties'][k],path+'.'+k)
 if isinstance(value,list):
  if 'minItems' in s:assert len(value)>=s['minItems'],path+' minItems'
  if 'maxItems' in s:assert len(value)<=s['maxItems'],path+' maxItems'
  for i,v in enumerate(value):schema(v,s.get('items',{}),path+f'[{i}]')

def parse_items(text):
 out={}
 name=None
 for line in text.splitlines():
  line=line.strip()
  if not line:continue
  if line.endswith(':') and not line.startswith(' '):name=line[:-1]
  elif line.startswith('model:') and name:out[name]=line.split(':',1)[1].strip()
 return out

def validate(dist):
 dist=pathlib.Path(dist)
 data={n:json.loads((dist/(n+'.json')).read_text()) for n in ('catalog','manifest','report')}
 for n,v in data.items():schema(v,json.loads((ROOT/'schemas'/(n+'.schema.json')).read_text()))
 manifest=data['manifest'];catalog=data['catalog'];report=data['report']
 assert manifest['minecraftVersion']==catalog['minecraftVersion']==report['minecraftVersion']
 assert manifest['assetVersion']==report['assetVersion']
 assert manifest['namespace']==catalog['namespace']==report['namespace']=='vanillamobs'
 assert hashlib.sha256((dist/'catalog.json').read_bytes()).hexdigest()==manifest['catalogSha256']
 assert manifest['sourceClientSha1']==report['sourceClientSha1']
 paths=[]
 for f in manifest['files']:
  p=pathlib.PurePosixPath(f['path']);assert str(p)==f['path'] and '..' not in p.parts and not p.is_absolute() and str(p).startswith('content/vanillamobs/')
  content=(dist/str(p)).read_bytes();assert len(content)==f['size'];assert hashlib.sha256(content).hexdigest()==f['sha256'];paths.append(str(p))
 assert paths==sorted(set(paths))
 assert set(paths)=={p.relative_to(dist).as_posix() for p in (dist/'content/vanillamobs').rglob('*') if p.is_file()}
 assert 'bundles: [main]' in (dist/'content/vanillamobs/pack.yml').read_text()
 assert f"version: {manifest['assetVersion']}" in (dist/'content/vanillamobs/pack.yml').read_text()
 registrations=parse_items((dist/'content/vanillamobs/items/mobs.yml').read_text())
 models=catalog['models']
 assert len(models)==report['requestedModelCount']
 assert report['candidateEntityCount']>0
 if 'defaultModelCount' in report:assert report['defaultModelCount']==report['candidateEntityCount']
 assert len({m['modelId'] for m in models})==len(models),'duplicate modelId'
 supported=[m for m in models if m['supported']]
 unsupported=[m for m in models if not m['supported']]
 assert report['successCount']==report['modelCount']==len(supported)
 assert report['unsupportedCount']==len(unsupported)
 assert report['extractionFailureCount']==sum(1 for x in report['unsupported'] if x['stage']=='extraction')
 assert report['unverifiedCount']==0 and not report['unverified']
 assert report['coverage']['supportedEntityCount']==len({m['entityType'] for m in supported})
 assert report['coverage']['candidateEntityCount']==report['candidateEntityCount']
 assert report['pngCount']==report['embeddedPngCount']>=report['uniquePngCount']
 for m in models:
  name=m['modelId'].split(':')[1]
  c=m['conditions']
  for k in ('age','pose','equipment','variant'):assert k in c
  assert c['age'] in ('adult','baby') and c['pose']=='standing' and c['equipment']=='none'
  assert m['display']=={'scale':2.5,'offsetX':0,'offsetY':0.001,'offsetZ':0,'yawOffsetDegrees':180}
  p=dist/'content/vanillamobs/assets/models'/(name+'.bbmodel')
  assert p.exists()==m['supported'],f'file presence mismatch {name}'
  assert (name in registrations)==m['supported'],f'registration mismatch {name}'
  assert (f"{name}:\n  material: PAPER\n  model: {name}" in (dist/'content/vanillamobs/items/mobs.yml').read_text())==m['supported']
  if m['supported']:
   if m['entityType']=='VILLAGER':
    types={'desert','jungle','plains','savanna','snow','swamp','taiga'}
    professions={'none','armorer','butcher','cartographer','cleric','farmer','fisherman','fletcher','leatherworker','librarian','mason','nitwit','shepherd','toolsmith','weaponsmith'}
    assert c['age']=='adult' and c['villagerType'] in types and c['variant']=='minecraft:'+c['villagerType']
    assert c['profession'] in professions and c['heldItem']=='none' and c['unhappy'] is False
    assert c['professionLevel']==1 if c['profession'] in ('none','nitwit') else 1<=c['professionLevel']<=5
   assert m['limitations'],name+' missing limitations'
   assert name in report['tests']['models'] and report['tests']['models'][name]['status']=='passed'
  else:
   assert m['limitations'],name+' unsupported without reason'
 assert len(report['failures'])==len(unsupported)
 assert len(report['successes'])==len(supported)
 assert set(report['successes'])=={m['modelId'] for m in supported}
 return data
if __name__=='__main__':
 validate(pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'dist'))
 print('PASS schema / manifest / registrations / supported-vs-unsupported files')
