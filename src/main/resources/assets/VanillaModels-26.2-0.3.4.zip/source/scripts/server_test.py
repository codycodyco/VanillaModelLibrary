#!/usr/bin/env python3
"""Offline-only integration run using an existing private Paper installation."""
import pathlib,shutil,subprocess,os,time,json,zipfile,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
source=pathlib.Path(os.environ['PAPER_SOURCE']); target=ROOT/'.cache/server-test'
target.mkdir(parents=True,exist_ok=True)
for name in ['libraries','versions','cache']:
 if not (target/name).exists():shutil.copytree(source/name,target/name)
for name in ['paper-26.2-134.jar','eula.txt']:shutil.copy2(source/name,target/name)
plugins=target/'plugins';plugins.mkdir(exist_ok=True)
shutil.copy2(source/'plugins/rp-engine-0.2.20.jar',plugins/'RPEngine.jar')
engine=plugins/'RPEngine';engine.mkdir(exist_ok=True)
(engine/'config.yml').write_text('config-version: 5\nhost:\n  mode: none\nedit:\n  enabled: false\ntelemetry:\n  enabled: false\nemotes:\n  bake: false\n')
installed=engine/'content/vanillamobs'
if installed.exists():shutil.rmtree(installed)
shutil.copytree(ROOT/'dist/content/vanillamobs',installed)
(target/'server.properties').write_text('server-ip=127.0.0.1\nserver-port=25688\nonline-mode=true\nlevel-name=extractor-test\nlevel-type=minecraft:flat\ngenerate-structures=false\nspawn-protection=0\nview-distance=2\nsimulation-distance=2\nmax-players=1\nenable-rcon=false\n')
log=ROOT/'build/server-test.log';log.parent.mkdir(exist_ok=True)
with log.open('w') as output:
 proc=subprocess.Popen([os.environ['JAVA_HOME']+'/bin/java','-Xms256M','-Xmx2G','-jar','paper-26.2-134.jar','--nogui'],cwd=target,stdin=subprocess.PIPE,stdout=output,stderr=subprocess.STDOUT,text=True)
 try:
  deadline=time.monotonic()+int(os.environ.get('SERVER_TEST_TIMEOUT_SECONDS','900'))
  while time.monotonic()<deadline and proc.poll() is None:
   data=log.read_text()
   if 'Done (' in data and (engine/'output/main.zip').exists():break
   time.sleep(1)
  assert proc.poll() is None and 'Done (' in log.read_text(),'Server startup failed; see build/server-test.log'
  proc.stdin.write('rp reload\n');proc.stdin.flush();time.sleep(5)
 finally:
  if proc.poll() is None:
   proc.stdin.write('stop\n');proc.stdin.flush()
   try:proc.wait(timeout=45)
   except subprocess.TimeoutExpired:proc.terminate();proc.wait(timeout=15)
pack=engine/'output/main.zip';catalog=json.loads((ROOT/'dist/catalog.json').read_text());items=[]
with zipfile.ZipFile(pack) as z:
 for model in catalog['models']:
  name=model['modelId'].split(':')[1];p=f'assets/vanillamobs/models/item/{name}.json';definition=f'assets/vanillamobs/items/{name}.json'
  if not model['supported']:
   assert p not in z.namelist() and definition not in z.namelist();continue
  generated=json.loads(z.read(p));expected=json.loads((ROOT/'build/converted'/(name+'.bbmodel.converted.json')).read_text())
  assert generated['elements']==expected['elements'],f'Server changed geometry {name}'
  d=json.loads(z.read(definition));assert d['model']['model']=='vanillamobs:item/'+name
  for slot,tex in generated['textures'].items():
   ns,path=tex.split(':');assert z.read(f'assets/{ns}/textures/{path}.png').startswith(b'\x89PNG')
  items.append(name)
result={'status':'passed','paper':'26.2-134','rpEngine':'0.2.20','registeredItems':items,'bundleSha256':hashlib.sha256(pack.read_bytes()).hexdigest(),'privateHosting':'host.mode=none; loopback only; no uploaded resources','installedFiles':{p.relative_to(engine/'content/vanillamobs').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (engine/'content/vanillamobs').rglob('*') if p.is_file()},'evidence':'build/server-test.log; actual startup + rp reload; output/main.zip models and item definitions verified'}
(ROOT/'build/server-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
