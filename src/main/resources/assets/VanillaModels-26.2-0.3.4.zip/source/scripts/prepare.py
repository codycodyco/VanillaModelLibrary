#!/usr/bin/env python3
"""Resolve the selected JAR through Mojang metadata; fetch hash-pinned runtime."""
import hashlib,json,pathlib,urllib.request,zipfile,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]; CACHE=ROOT/'.cache'; CACHE.mkdir(exist_ok=True)
def fetch(url,path,sha=None):
    if not path.exists() or sha and hashlib.sha1(path.read_bytes()).hexdigest()!=sha:
        with urllib.request.urlopen(url,timeout=60) as r: data=r.read()
        if sha and hashlib.sha1(data).hexdigest()!=sha: raise ValueError('SHA-1 mismatch: '+url)
        path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(data)
    return path.read_bytes()
def main():
    source=pathlib.Path(sys.argv[1]); digest=hashlib.sha1(source.read_bytes()).hexdigest()
    with zipfile.ZipFile(source) as z: version=json.loads(z.read('version.json'))['id']
    manifest=json.loads(urllib.request.urlopen('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json').read())
    assert version=='26.2','Only 26.2 adapter has been audited'
    entry=next(x for x in manifest['versions'] if x['id']==version)
    meta=json.loads(fetch(entry['url'],CACHE/'version.json',entry['sha1']))
    assert meta['downloads']['client']['sha1']==digest,'Selected JAR is not official client'
    fetch(meta['downloads']['client']['url'],CACHE/'client.jar',digest)
    jars=[str(CACHE/'client.jar')]
    for lib in meta['libraries']:
        artifact=lib.get('downloads',{}).get('artifact')
        if artifact:
            p=CACHE/'libraries'/artifact['path']; fetch(artifact['url'],p,artifact['sha1']); jars.append(str(p))
    mappings=meta['downloads'].get('client_mappings')
    if mappings: fetch(mappings['url'],CACHE/'client-mappings.txt',mappings['sha1'])
    else:
        with zipfile.ZipFile(CACHE/'client.jar') as z: assert 'net/minecraft/client/model/geom/LayerDefinitions.class' in z.namelist(),'No mappings and not named client'
    provenance={'minecraftVersion':version,'sourceClientSha1':digest,'metadataSha1':entry['sha1'],'metadataUrl':entry['url'],'javaMajor':meta['javaVersion']['majorVersion'],'mappingMode':'official-named-bytecode' if not mappings else 'requires-remapping'}
    if mappings: raise RuntimeError('Obfuscated clients are unsupported; remapping adapter required')
    (CACHE/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n'); (CACHE/'classpath.txt').write_text(':'.join(jars))
    print(json.dumps(provenance))
if __name__=='__main__': main()
