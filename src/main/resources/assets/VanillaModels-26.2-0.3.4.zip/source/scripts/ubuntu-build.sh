#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${JAVA_HOME:?Set JAVA_HOME to an installed JDK 25 on Ubuntu}"
[[ "$(uname -s)" == Linux ]] || { echo 'Run on Ubuntu, not the Mac'; exit 1; }
[[ $# == 1 ]] || { echo 'Usage: JAVA_HOME=/path/jdk-25 scripts/ubuntu-build.sh /path/official-client.jar'; exit 1; }
mkdir -p build
python3 scripts/prepare.py "$1"
python3 scripts/fetch_compat.py
"${GRADLE_BIN:-./gradlew}" --no-daemon clean classes compatClasses check
python3 -c 'import pathlib,json;pathlib.Path("build/gradle-result.json").write_text(json.dumps({"status":"passed","evidence":"Ubuntu JDK 25; Gradle clean classes compatClasses check"})+"\n")'
CP="build/classes/java/main:$(cat .cache/classpath.txt)"
# Keep the original single-cow gate: extraction, conversion, real upstream converter.
"$JAVA_HOME/bin/java" -cp "$CP" extractor.Extract cow .cache/raw
python3 scripts/convert.py .cache/raw .cache/cow_adult.bbmodel .cache/client.jar
"$JAVA_HOME/bin/java" -cp "build/classes/java/compat:$CP" extractor.Verify .cache/cow_adult.bbmodel .cache/raw
# Full registry-driven default extraction, conversion and verification.
"$JAVA_HOME/bin/java" -Xmx2G -cp "$CP" extractor.ExtractAll .cache/all-raw .cache/client.jar
python3 scripts/build_variants.py dist
python3 scripts/validate.py dist
python3 scripts/package.py
