#!/usr/bin/env python3
"""Build the private Vanilla Mobs RP Engine content from official 26.2 data.

Modes:
  --all-defaults  one exact default adult appearance per non-MISC mob
  --all-variants  (phase two) exact adult/baby/climate/colour/overlay variants

The extractor never guesses a layer or texture from an entity name.  Java
ExtractAll reads the official entity registry, renderers and LayerDefinitions;
this script applies the maintainable recipes in recipes/*.json, runs the real
converter, and rejects anything it cannot represent exactly.
"""
import argparse,base64,copy,hashlib,json,math,os,pathlib,shutil,subprocess,sys,zipfile
from convert import convert,dump,Unsupported

ROOT=pathlib.Path(__file__).resolve().parents[1]
RAW=ROOT/'.cache/all-raw'
CACHE=ROOT/'.cache'
BUILD=ROOT/'.cache/build'
NS='vanillamobs'
GLOBAL_LIMITATION='Static snapshot of the official default render state; no animation, movement, equipment or unlisted appearance is covered.'
GLOBAL_DISPLAY={'scale':2.5,'offsetX':0,'offsetY':0.001,'offsetZ':0,'yawOffsetDegrees':180}

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def java_bin():
    home=os.environ.get('JAVA_HOME')
    return str(pathlib.Path(home)/'bin/java') if home else 'java'
def cp(compat=False):
    parts=[]
    if compat:parts.append(str(ROOT/'build/classes/java/compat'))
    parts+= [str(ROOT/'build/classes/java/main'),(CACHE/'classpath.txt').read_text().strip()]
    return ':'.join(parts)
def run(cmd,check=True,capture=True):
    result=subprocess.run(cmd,check=False,text=True,capture_output=capture)
    if check and result.returncode:
        raise RuntimeError(' '.join(map(str,cmd))+'\n'+(result.stderr or result.stdout))
    return result
def norm_texture(path):
    if not path:return None
    if path.startswith('minecraft:'):path=path[len('minecraft:'):]
    return path

def load_recipes():
    return json.loads((ROOT/'recipes/defaults.json').read_text())
def load_raw():
    if not (RAW/'inventory.json').exists():
        run([java_bin(),'-cp',cp(),'extractor.ExtractAll',str(RAW),str(CACHE/'client.jar')])
    inv=json.loads((RAW/'inventory.json').read_text())
    entries={}
    for p in sorted((RAW/'entities').glob('*.json')):
        d=json.loads(p.read_text());entries[d['entityType']]=d
    return inv,entries

def base_conditions(recipe,entity_path):
    cond=dict(recipe['defaultConditions'])
    cond['variant']='minecraft:'+entity_path
    cond.update(recipe.get('conditions',{}).get('minecraft:'+entity_path,{}))
    return cond

def display():return dict(GLOBAL_DISPLAY)
def setup_is_usable(status):
    if not status or status=='ok':return True
    return 'NoSuchMethodException' in status

def apply_pose_override(entity,tree,recipe):
    """Apply an explicitly recorded static-pose substitution to a copied tree."""
    specs=recipe.get('poseOverrides',{}).get(entity,[])
    if not specs:return tree,[]
    result=copy.deepcopy(tree);notes=[]
    for spec in specs:
        node=result
        path=spec['partPath']
        for part in path:
            children=node.get('children',{})
            if part not in children:
                raise Unsupported(f"Pose override part is absent: {'/'.join(path)}")
            node=children[part]
        axis=spec['axis'];before=float(node.get(axis,0.0));expected=float(spec['expectedRadians'])
        if not math.isclose(before,expected,rel_tol=0,abs_tol=1e-12):
            raise Unsupported(f"Pose override source changed at {'/'.join(path)}.{axis}: expected {expected}, got {before}")
        target=float(spec['replacementRadians']);node[axis]=target
        notes.append(spec['limitation'])
    return result,notes

def select_overlay(raw,spec):
    for layer in raw.get('renderLayers',[]):
        for model in layer.get('models',[]):
            if model.get('layer')!=spec.get('layer'):continue
            if spec.get('field') and model.get('field')!=spec.get('field'):continue
            if 'baby' in (model.get('field') or ''):continue
            return model
    return None

def prepare_tinted(recipe,entries):
    jobs=[];details={}
    outdir=BUILD/'textures'
    if outdir.exists():shutil.rmtree(outdir)
    for entity,specs in recipe.get('overlays',{}).items():
        raw=entries.get(entity)
        if not raw:continue
        for spec in specs:
            if 'tintFrom' not in spec:continue
            value=raw.get(spec['tintFrom'])
            if value is None:continue
            name=f"{entity.split(':')[1]}_{spec['key']}_{value & 0xffffffff:08x}"
            out=outdir/(name+'.png')
            jobs.append({'name':name,'out':str(out),'source':spec['texture'],'mode':'tint','tintArgb':value})
            details[(entity,spec['key'])]={'path':out,'argb':value,'name':name}
    for entity,layers in recipe.get('staticTints',{}).items():
        raw=entries.get(entity)
        if not raw:continue
        base_texture=norm_texture(recipe.get('textureOverrides',{}).get(entity) or raw.get('texture'))
        for key,info in layers.items():
            if key=='main':source=base_texture
            else:
                source=None
                for spec in recipe.get('overlays',{}).get(entity,[]):
                    if spec.get('key')==key:source=base_texture if spec.get('texture')=='@base' else norm_texture(spec.get('texture'))
                if source is None:continue
            value=info['argb'];tag=info.get('name',f"{value & 0xffffffff:08x}")
            name=f"{entity.split(':')[1]}_{key}_{tag}"
            out=outdir/(name+'.png')
            jobs.append({'name':name,'out':str(out),'source':source,'mode':'tint','tintArgb':value})
            details[(entity,key)]={'path':out,'argb':value,'name':name}
    for entity,spec in recipe.get('composites',{}).items():
        if entity not in entries:continue
        name=entity.split(':')[1]+'_composite'
        out=outdir/(name+'.png')
        jobs.append({'name':name,'out':str(out),'mode':'over',**spec})
        details[(entity,'main')]={'path':out,'name':name}
    if not jobs:return details
    job_file=outdir/'jobs.json';outdir.mkdir(parents=True,exist_ok=True)
    dump(job_file,{'jobs':jobs})
    report=outdir/'report.json'
    run([java_bin(),'-cp',cp(),'extractor.Textures',str(CACHE/'client.jar'),str(job_file),str(report)])
    checked=json.loads(report.read_text())['textures']
    for item in checked:
        for key,info in details.items():
            if info['name']==item['name']:
                info.update(item);info['bytes']=(outdir/(item['name']+'.png')).read_bytes()
    return details

def jar_bytes(jar,texture):
    entry='assets/minecraft/'+texture
    try:return jar.read(entry)
    except KeyError:raise Unsupported('Official texture missing: '+texture)

def texture_check(model,specs,jar,tinted):
    """Return (ok, evidence). Compares every embedded PNG to its official source."""
    layer_paths={s['layer']:s['texture'] for s in specs}
    layer_tint={s['layer']:s.get('data') for s in specs}
    mapping=model.get('layer_textures',{})
    seen={}
    for layer,name in mapping.items():
        texture=layer_paths.get(layer)
        if texture is None:return False,'No texture path for layer '+layer
        if layer=='main':texture=specs[0]['texture']
        embedded=None
        for t in model['textures']:
            if t['name']==name:embedded=t;break
        if embedded is None:return False,'Texture slot missing '+name
        data=base64.b64decode(embedded['source'].split(',',1)[1])
        expected=layer_tint.get(layer)
        if expected is None:expected=jar_bytes(jar,texture)
        if data!=expected:return False,f'Embedded PNG differs from official/processed source: {layer}/{texture}'
        if embedded['uv_width']!=int.from_bytes(expected[16:20],'big') or embedded['uv_height']!=int.from_bytes(expected[20:24],'big'):
            return False,'PNG dimensions changed: '+layer
        seen[layer]=hashlib.sha256(data).hexdigest()
    return True,f'{len(model["textures"])} embedded PNG(s) byte-identical to official/processed source; alpha preserved'

def write_layers(work,layers):
    work.mkdir(parents=True,exist_ok=True)
    shutil.copy2(CACHE/'raw/face-layout.json',work/'face-layout.json')
    for layer in layers:
        dump(work/(layer['layer']+'.json'),{layer['layer']:layer['tree']})

def render_appearance(model_id,layers,jar,content):
    """Convert + verify one already-assembled appearance. No catalog policy."""
    work=BUILD/'raw'/model_id.split(':')[1]
    if work.exists():shutil.rmtree(work)
    write_layers(work,layers)
    try:
        model=convert(model_id,layers,jar,work,{s['layer']:s.get('data') for s in layers if s.get('data')})
    except Unsupported as error:
        category='orientation' if ('orientation' in str(error) or 'Sheared' in str(error)) else ('uv' if ('UV' in str(error) or 'cuboid' in str(error)) else 'conversion')
        return {'supported':False,'stage':'conversion','category':category,'reason':str(error)}
    out=content/'assets/models'/(model_id.split(':')[1]+'.bbmodel')
    out.parent.mkdir(parents=True,exist_ok=True);dump(out,model)
    args=[java_bin(),'-cp',cp(True),'extractor.Verify',str(out),str(work)]
    result=run(args,check=False)
    if result.returncode:
        lines=(result.stderr or result.stdout).strip().splitlines();reason='Verification failed: '+(lines[-1] if lines else 'unknown')
        out.unlink(missing_ok=True)
        for bad in out.parent.glob(out.name+'.converted.json'):bad.unlink(missing_ok=True)
        return {'supported':False,'stage':'verification','category':'verification','reason':reason}
    evidence=result.stdout.strip()
    ok,tex_evidence=texture_check(model,layers,jar,{})
    if not ok:
        out.unlink(missing_ok=True)
        return {'supported':False,'stage':'texture','category':'texture','reason':'Texture verification failed: '+tex_evidence}
    converted=out.with_name(out.name+'.converted.json')
    if converted.exists():
        (ROOT/'build/converted').mkdir(exist_ok=True,parents=True);shutil.move(str(converted),str(ROOT/'build/converted'/converted.name))
    cube_count=len(model['elements']);face_count=sum(len(e['faces']) for e in model['elements'])
    png_count=len(model['textures'])
    unique_pngs={hashlib.sha256(base64.b64decode(t['source'].split(',',1)[1])).hexdigest() for t in model['textures']}
    rotation_count=sum(1 for e in model['elements'] if e.get('rotation'))
    return {'supported':True,'modelId':model_id,'path':out,'model':model,'evidence':evidence+'; '+tex_evidence,
            'cubeCount':cube_count,'faceCount':face_count,'pngCount':png_count,'uniquePngs':unique_pngs,
            'rotationCount':rotation_count,'bytes':out.stat().st_size,'layerCount':len(layers),
            'textureEvidence':tex_evidence,'overlayKeys':[s['layer'] for s in layers[1:]]}

def build_model(entity,raw,recipe,tinted,jar,items,content):
    path=entity.split(':')[1]
    model_id=f'{NS}:{path}_adult'
    cond=base_conditions(recipe,path)
    limitations=[GLOBAL_LIMITATION]+list(recipe.get('limitations',{}).get(entity,[]))
    policy=recipe.get('unsupported',{}).get(entity)
    if policy:
        return {'supported':False,'stage':policy['stage'],'category':'policy','reason':policy['reason'],'conditions':cond,'limitations':limitations+[policy['reason']]}
    if raw.get('status')!='extracted':
        reason=raw.get('error','ExtractAll failed')
        return {'supported':False,'stage':'extraction','category':'extraction','reason':reason,'conditions':cond,'limitations':limitations+[reason]}
    base=raw['base'];base_texture=norm_texture(recipe.get('textureOverrides',{}).get(entity) or raw.get('texture'))
    use_bind=entity in recipe.get('bindPose',[]) and raw.get('baseBind')
    if use_bind:
        base={'tree':raw['baseBind']['tree']}
        limitations.append('Delivered with the official bind pose, not the vanilla idle pose.')
    elif entity in recipe.get('bindPose',[]):
        reason='Requested bind-pose extraction but the extractor did not record baseBind'
        return {'supported':False,'stage':'extraction','category':'extraction','reason':reason,'conditions':cond,'limitations':limitations+[reason]}
    try:
        tree,pose_notes=apply_pose_override(entity,base['tree'],recipe)
        base={'tree':tree};limitations.extend(pose_notes)
    except Unsupported as error:
        reason=str(error)
        return {'supported':False,'stage':'pose','category':'policy','reason':reason,'conditions':cond,'limitations':limitations+[reason]}
    if not base_texture:
        reason='No single base texture discovered for renderer'
        return {'supported':False,'stage':'texture','category':'texture','reason':reason,'conditions':cond,'limitations':limitations+[reason]}
    if not setup_is_usable(raw.get('setupAnim')):
        reason='Official setupAnim failed: '+raw['setupAnim']
        return {'supported':False,'stage':'extraction','category':'extraction','reason':reason,'conditions':cond,'limitations':limitations+[reason]}
    main_entry={'layer':'main','tree':base['tree'],'texture':base_texture}
    base_tint=tinted.get((entity,'main'))
    if base_tint:main_entry['data']=base_tint['bytes']
    layers=[main_entry]
    for spec in recipe.get('overlays',{}).get(entity,[]):
        model=select_overlay(raw,spec)
        if model is None:
            reason=f"Required overlay {spec['layer']} field {spec.get('field')} was not found in the official renderer"
            return {'supported':False,'stage':'overlay','category':'overlay','reason':reason,'conditions':cond,'limitations':limitations+[reason]}
        if not setup_is_usable(model.get('setupAnim')):
            reason=f"Overlay setupAnim failed: {model['setupAnim']}"
            return {'supported':False,'stage':'extraction','category':'extraction','reason':reason,'conditions':cond,'limitations':limitations+[reason]}
        texture=base_texture if spec['texture']=='@base' else norm_texture(spec['texture'])
        overlay_tree=model.get('bindTree') if entity in recipe.get('bindPose',[]) else None
        if overlay_tree is None:overlay_tree=model['tree']
        entry={'layer':spec['key'],'tree':overlay_tree,'texture':texture}
        tint=tinted.get((entity,spec['key']))
        if tint:entry['data']=tint['bytes']
        layers.append(entry)
        if entity in recipe.get('bindPose',[]) and model.get('bindTree') is not None:
            limitations.append(f"{spec['key']} layer uses its official bind pose to match the simplified dance pose.")
        if 'NoSuchMethodException' in (model.get('setupAnim') or ''):
            limitations.append(f"{spec['key']} layer model has no setupAnim; official bind pose used.")
    if 'NoSuchMethodException' in (raw.get('setupAnim') or ''):
        limitations.append('Base model has no setupAnim; official bind pose used.')
    result=render_appearance(model_id,layers,jar,content)
    if result['supported']:
        result['entityType']=raw['entityType'];result['conditions']=cond;result['limitations']=limitations
    else:
        result['conditions']=cond;result['limitations']=limitations+[result['reason']]
    return result

def build_defaults(dist,recipe=None,jar=None):
    recipe=recipe or load_recipes();inv,entries=load_raw()
    jar=jar or zipfile.ZipFile(CACHE/'client.jar')
    BUILD.mkdir(parents=True,exist_ok=True)
    for sub in ('models','converted'):
        p=BUILD/sub
        if p.exists():shutil.rmtree(p)
    tinted=prepare_tinted(recipe,entries)
    content=dist/'content/vanillamobs'
    if dist.exists():shutil.rmtree(dist)
    (content/'assets/models').mkdir(parents=True,exist_ok=True);(content/'items').mkdir(parents=True,exist_ok=True)
    (content/'pack.yml').write_text('name: Vanilla Mobs\nversion: '+recipe['assetVersion']+'\nbundles: [main]\n')
    models=[];supported=[];unsupported=[];failures=[];geometry=[];uv=[];checks={};items=[];all_hashes=set()
    cube_total=face_total=png_total=0;bbmodel_bytes=0
    candidates=sorted(e['entityType'] for e in inv['entities'] if e.get('candidate'))
    for entity in candidates:
        raw=entries[entity]
        result=build_model(entity,raw,recipe,tinted,jar,items,content)
        path=entity.split(':')[1]
        record={'entityType':path.upper(),'modelId':f'{NS}:{path}_adult','conditions':result['conditions'],
                'display':display(),'supported':result['supported'],'limitations':result['limitations']}
        models.append(record)
        if result['supported']:
            supported.append(result['modelId']);cube_total+=result['cubeCount'];face_total+=result['faceCount'];png_total+=result['pngCount']
            bbmodel_bytes+=result['bytes'];all_hashes|=result['uniquePngs']
            items.append(f"{result['modelId'].split(':')[1]}:\n  material: PAPER\n  model: {result['modelId'].split(':')[1]}")
            checks[result['modelId'].split(':')[1]]={'status':'passed','evidence':result['evidence'],
                'cubes':result['cubeCount'],'faces':result['faceCount'],'pngs':result['pngCount'],
                'elementRotations':result['rotationCount'],'layers':result['layerCount'],
                'overlays':result['overlayKeys'],'bytes':result['bytes']}
        else:
            entry={'modelId':f'{NS}:{path}_adult','entityType':path.upper(),'stage':result['stage'],'category':result.get('category','unsupported'),
                   'reason':result['reason'],'limitations':result['limitations']}
            unsupported.append(entry);failures.append(entry)
            if result['stage']=='conversion':
                if 'orientation' in result['reason'] or 'Sheared' in result['reason']:geometry.append(entry)
                if 'UV' in result['reason'] or 'cuboid' in result['reason']:uv.append(entry)
            checks[path+'_adult']={'status':'failed','stage':result['stage'],'evidence':result['reason']}
            print(f"UNSUPPORTED {path}: {result['reason']}",flush=True)
    (content/'items/mobs.yml').write_text('\n'.join(sorted(items))+'\n')
    dump(dist/'catalog.json',{'schema':1,'minecraftVersion':recipe['minecraftVersion'],'namespace':NS,'models':models})
    excluded=inv['entityTypeCount']-inv['candidateCount']
    by_category={}
    for x in unsupported:
        by_category.setdefault(x.get('category','unsupported'),[]).append(x['entityType'].lower())
    coverage={'candidateEntityCount':len(candidates),'supportedEntityCount':len(supported),
              'unsupportedEntityCount':len(unsupported),'extractionFailureCount':sum(1 for x in unsupported if x['stage']=='extraction'),
              'unverifiedEntityCount':0,'successPercent':round(100*len(supported)/len(candidates),2)}
    report={'schema':1,'minecraftVersion':recipe['minecraftVersion'],'namespace':NS,'assetVersion':recipe['assetVersion'],
            'sourceClientSha1':json.loads((CACHE/'provenance.json').read_text())['sourceClientSha1'],
            'mappingMode':json.loads((CACHE/'provenance.json').read_text())['mappingMode'],
            'registryEntityTypeCount':inv['entityTypeCount'],'layerDefinitionCount':inv['layerDefinitionCount'],
            'excludedEntityTypeCount':excluded,'candidateEntityCount':len(candidates),
            'requestedModelCount':len(candidates),'successCount':len(supported),'modelCount':len(supported),
            'unsupportedCount':len(unsupported),'extractionFailureCount':sum(1 for x in unsupported if x['stage']=='extraction'),
            'unverifiedCount':0,'cubeCount':cube_total,'faceCount':face_total,'pngCount':png_total,
            'embeddedPngCount':png_total,'uniquePngCount':len(all_hashes),
            'deduplication':{'embeddedPngCount':png_total,'uniquePngCount':len(all_hashes),
                             'scope':'per-model SHA-256; each standalone bbmodel embeds every texture it needs'},
            'coverage':coverage,'unsupportedByCategory':by_category,'successes':supported,'unsupported':unsupported,'failures':failures,
            'extractionFailures':[x for x in unsupported if x['stage']=='extraction'],
            'unverified':[],'geometryIssues':geometry,'uvIssues':uv,
            'assets':{'bbmodelBytes':bbmodel_bytes,'contentBytes':sum(p.stat().st_size for p in content.rglob('*') if p.is_file())},
            'rpEngineCompatibility':{'revision':'5454b685cceccfd291a8345da84a4c49441c2773','actualConverter':f'passed for {len(supported)} supported models',
                'singleItemDisplay':True,'meshCount':0,'animationCount':0,
                'elementRotationCount':sum(v.get('elementRotations',0) for v in checks.values() if v['status']=='passed'),
                'coordinateQuantization':'upstream BbModel rounds from/to and rotation origins to 0.01 model units',
                'uvQuantization':'upstream BbModel rounds UVs to 0.01 of the 0..16 space',
                'serverBundleBuild':'unverified','clientVisualCheck':'unverified'},
            'tests':{'models':checks,'pythonTests':{'status':'unverified'},'schemaAndHashes':{'status':'unverified'},
                     'determinism':{'status':'unverified'},'server':{'status':'unverified'},
                     'clientVisual':{'status':'unverified'},'gradleBuild':{'status':'unverified'},
                     'unsupportedRejection':{'status':'passed','evidence':f'{len(unsupported)} entities rejected with exact stage/reason; no bbmodel or ITEM registration emitted'}},
            'notes':['Candidates come from the official EntityType registry; 72 non-MISC-excluded entity types are MISC and not creatures.',
                     'Each supported model preserves the official ModelPart hierarchy, default setupAnim pose, per-face UVs, embedded alpha and all required overlay model layers.',
                     'Any orientation that RP Engine cannot express as a single-axis 0/+-22.5/+-45 element rotation is rejected, never snapped.']}
    dump(dist/'report.json',report)
    files=[]
    for p in sorted(content.rglob('*')):
        if p.is_file():files.append({'path':p.relative_to(dist).as_posix(),'sha256':sha(p),'size':p.stat().st_size})
    dump(dist/'manifest.json',{'schema':1,'minecraftVersion':recipe['minecraftVersion'],'namespace':NS,'assetVersion':recipe['assetVersion'],
                               'sourceClientSha1':report['sourceClientSha1'],'catalogSha256':sha(dist/'catalog.json'),'files':files})
    print(json.dumps({'success':len(supported),'unsupported':len(unsupported),'cubes':cube_total,'faces':face_total,'pngs':png_total,'contentBytes':report['assets']['contentBytes']}),flush=True)
    return report

def build(dist,recipe=None):
    return build_defaults(pathlib.Path(dist),recipe)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('dist',nargs='?',default='dist')
    ap.add_argument('--all-defaults',action='store_true')
    ap.add_argument('--all-variants',action='store_true')
    args=ap.parse_args()
    if args.all_variants:
        from build_variants import build_variants
        build_variants(pathlib.Path(args.dist))
    else:
        build_defaults(pathlib.Path(args.dist))
