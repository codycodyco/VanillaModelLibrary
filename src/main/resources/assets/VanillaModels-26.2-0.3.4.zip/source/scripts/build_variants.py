#!/usr/bin/env python3
"""Phase two: exact default plus adult/baby/climate/colour/overlay variants.

Defaults are built first through the verified defaults pipeline.  Every extra
appearance is then explicit: an official model layer, an official texture (or
an official colour tint), and a conjunctive condition set.  Anything that has
no exact model is emitted as supported=false with a reason and is never
registered as an ITEM.
"""
import base64,hashlib,json,pathlib,shutil,sys,zipfile
from build_assets import (ROOT,RAW,CACHE,BUILD,NS,GLOBAL_LIMITATION,GLOBAL_DISPLAY,
    build_defaults,load_recipes,load_raw,base_conditions,norm_texture,jar_bytes,
    texture_check,render_appearance,dump,sha,cp,java_bin,run,setup_is_usable,
    apply_pose_override)
from convert import Unsupported

VARDATA=CACHE/'variant-data.json'
VTEX=ROOT/'.cache/variants/tex'
GLOBAL_BABY='Baby appearance uses the official baby ModelLayer and baby texture; static pose only.'

def ensure_variant_data():
    if not VARDATA.exists() or not {'villagerTypes','villagerProfessions','villagerLevels'}<=set(json.loads(VARDATA.read_text())):
        run([java_bin(),'-cp',cp(),'extractor.VariantData',str(VARDATA)])
    return json.loads(VARDATA.read_text())

def jar_has(jar,path):return ('assets/minecraft/'+path) in jar.namelist()

def find_renderer_model(raw,key):
    for m in raw.get('rendererModels',[]):
        if m.get('key')==key:return m
    return None

def find_layer_model(raw,layer,field=None):
    for layerInfo in raw.get('renderLayers',[]):
        for m in layerInfo.get('models',[]):
            if m.get('layer')!=layer:continue
            if field and m.get('field')!=field:continue
            return m
    return None

def color_map(vardata,key):
    return {x['name']:x['argb'] for x in vardata[key]}

def data_variant(entity,variant):
    path=CACHE/f'data-{entity}-{variant}.json'
    if path.exists():return json.loads(path.read_text())
    import zipfile
    name=entity.split(':')[1]
    entry=f'data/minecraft/{name}_variant/{variant}.json'
    with zipfile.ZipFile(CACHE/'client.jar') as z:
        try:data=json.loads(z.read(entry))
        except KeyError:return {}
    path.write_text(json.dumps(data));return data

def asset_texture(asset):
    if not asset:return None
    if asset.startswith('minecraft:'):asset=asset[len('minecraft:'):]
    return 'textures/'+asset+'.png'

def derive_baby_texture(entity,base_texture,variant=None):
    name=entity.split(':')[1]
    if name in ('cow','pig','chicken'):
        data=data_variant(entity,variant or 'temperate')
        return asset_texture(data.get('baby_asset_id'))
    if not base_texture:return None
    if name=='sniffer':return 'textures/entity/sniffer/snifflet.png'
    if base_texture.endswith('_baby.png'):return base_texture
    return base_texture[:-4]+'_baby.png'

def tree_uv_rectangles(tree,width,height):
    rects=set()
    def visit(part):
        if not part.get('visible',True):return
        if not part.get('skipDraw',False):
            for cube in part.get('cubes',[]):
                for face in cube:
                    points=[(v[3]*width,v[4]*height) for v in face['vertices']]
                    values=[min(x for x,y in points),min(y for x,y in points),max(x for x,y in points),max(y for x,y in points)]
                    rounded=tuple(int(round(x)) for x in values)
                    if any(abs(a-b)>1e-6 for a,b in zip(values,rounded)):raise Unsupported('Villager UV mask is not pixel-aligned')
                    if rounded[0]<rounded[2] and rounded[1]<rounded[3]:rects.add(rounded)
        for child in part.get('children',{}).values():visit(child)
    visit(tree)
    return [list(r) for r in sorted(rects)]

def villager_hat(jar,kind,name):
    path=f'assets/minecraft/textures/entity/villager/{kind}/{name}.png.mcmeta'
    try:meta=json.loads(jar.read(path))
    except KeyError:return 'none'
    hat=meta.get('villager',{}).get('hat','none')
    if hat not in ('none','partial','full'):raise Unsupported(f'Unknown official villager hat metadata: {kind}/{name}={hat}')
    return hat

def prepare_variant_textures(vardata,entries,jar,recipe):
    if VTEX.exists():shutil.rmtree(VTEX)
    VTEX.mkdir(parents=True)
    jobs=[];prepared={}
    def add(name,source,argb):
        if name in prepared:return
        out=VTEX/(name+'.png')
        jobs.append({'name':name,'out':str(out),'source':source,'mode':'tint','tintArgb':argb})
        prepared[name]={'path':out,'argb':argb}
    wools=color_map(vardata,'sheepWoolColors')
    for color,argb in wools.items():add('sheep_wool_'+color,'textures/entity/sheep/sheep_wool.png',argb)
    add('sheep_wool_baby_white','textures/entity/sheep/sheep_wool_baby.png',wools['white'])
    white=color_map(vardata,'dyeColors')['white']
    patterns={p['name']:p for p in vardata['fishPatterns']}
    for shape,body in [('small','a'),('large','b')]:
        add('fish_body_'+shape,'textures/entity/fish/tropical_'+body+'.png',white)
        for p in vardata['fishPatterns']:
            idx=p['packedId']%6+1
            add('fish_pattern_'+shape+'_'+p['name'],f'textures/entity/fish/tropical_{body}_pattern_{idx}.png',white)
    villager=entries['minecraft:villager'];nohat=find_layer_model(villager,'minecraft:villager_no_hat#main','noHatModel')
    if nohat is None:raise Unsupported('Official adult villager no-hat model was not extracted')
    base='textures/entity/villager/villager.png';base_bytes=jar.read('assets/minecraft/'+base)
    width=int.from_bytes(base_bytes[16:20],'big');height=int.from_bytes(base_bytes[20:24],'big')
    nohat_mask=tree_uv_rectangles(nohat['tree'],width,height);villagers=[]
    types=[x.split(':',1)[1] for x in vardata['villagerTypes']]
    professions=[x.split(':',1)[1] for x in vardata['villagerProfessions']]
    levels={x['level']:x['texture'].split(':',1)[-1] for x in vardata['villagerLevels']}
    if sorted(levels)!=list(range(1,len(levels)+1)):raise Unsupported('Official villager level map is not contiguous from level 1')
    policy=recipe['villagerVariants'];selected_types=set(policy['types']);selected_levels=sorted(set(policy['levels']))
    if not selected_types<=set(types) or not set(selected_levels)<=set(levels):raise Unsupported('Villager variant recipe references a type or level absent from the official registry')
    for village_type in types:
        if village_type not in selected_types:continue
        type_texture=f'textures/entity/villager/type/{village_type}.png'
        if not jar_has(jar,type_texture):raise Unsupported('Official villager type texture missing: '+type_texture)
        type_hat=villager_hat(jar,'type',village_type)
        for profession in professions:
            profession_levels=[1] if profession in ('none','nitwit') else selected_levels
            profession_hat='none';profession_texture=None
            if profession!='none':
                profession_texture=f'textures/entity/villager/profession/{profession}.png'
                if not jar_has(jar,profession_texture):raise Unsupported('Official villager profession texture missing: '+profession_texture)
                profession_hat=villager_hat(jar,'profession',profession)
            full_type=profession_hat=='none' or (profession_hat=='partial' and type_hat!='full')
            for level in profession_levels:
                if village_type=='plains' and profession=='none':continue
                name=f'villager_{village_type}_{profession}_level_{level}_adult'
                overlays=[{'source':type_texture,'binaryAlpha':True}]
                if not full_type:overlays[0]['maskRects']=nohat_mask
                if profession_texture:overlays.append({'source':profession_texture,'binaryAlpha':True})
                if profession not in ('none','nitwit'):
                    level_texture=f'textures/entity/villager/profession_level/{levels[level]}.png'
                    if not jar_has(jar,level_texture):raise Unsupported('Official villager level texture missing: '+level_texture)
                    overlays.append({'source':level_texture,'binaryAlpha':True})
                out=VTEX/(name+'.png');jobs.append({'name':name,'out':str(out),'source':base,'mode':'stack','overlays':overlays})
                prepared[name]={'path':out,'name':name}
                villagers.append({'name':name,'type':village_type,'profession':profession,'level':level,
                    'typeModel':'full' if full_type else 'no_hat','typeHat':type_hat,'professionHat':profession_hat})
    jp=VTEX/'jobs.json';dump(jp,{'jobs':jobs});report=VTEX/'report.json'
    run([java_bin(),'-cp',cp(),'extractor.Textures',str(CACHE/'client.jar'),str(jp),str(report)])
    checked={x['name']:x for x in json.loads(report.read_text())['textures']}
    for name,info in prepared.items():
        info.update(checked[name]);info['bytes']=(VTEX/(name+'.png')).read_bytes()
    return prepared,villagers

def conditions_for(entity,recipe,age='adult',**extra):
    cond=base_conditions(recipe,entity.split(':')[1])
    cond['age']=age
    for k,v in extra.items():
        if v is None:cond.pop(k,None)
        else:cond[k]=v
    return cond

def make_layers(main_tree,main_tex,data=None,overlays=()):
    main={'layer':'main','tree':main_tree,'texture':main_tex}
    if data:main['data']=data
    layers=[main]
    for key,tree,texture,tint in overlays:
        entry={'layer':key,'tree':tree,'texture':texture}
        if tint:entry['data']=tint
        layers.append(entry)
    return layers

def add_record(catalog,record):catalog.append(record)

def build_variants(dist,recipe=None):
    dist=pathlib.Path(dist);recipe=recipe or load_recipes()
    defaults_report=build_defaults(dist,recipe)
    jar=zipfile.ZipFile(CACHE/'client.jar')
    inv,entries=load_raw()
    vardata=ensure_variant_data();prepared,villager_appearances=prepare_variant_textures(vardata,entries,jar,recipe)
    catalog=json.loads((dist/'catalog.json').read_text());report=json.loads((dist/'report.json').read_text())
    content=dist/'content/vanillamobs';model_dir=content/'assets/models'
    def parse_blocks(text):
        blocks=[]
        for line in text.splitlines():
            if not line.strip():continue
            if line.startswith('  '):blocks[-1]+='\n'+line
            else:blocks.append(line)
        return blocks
    items=parse_blocks((content/'items/mobs.yml').read_text())
    base_records={m['entityType']:m for m in catalog['models']}
    checks=report['tests']['models'];variant_records=[];variant_failures=[];not_covered=[]
    stats={'cubes':0,'faces':0,'pngs':0,'bytes':0,'rotations':0,'families':{}};unique_pngs=set()
    wools=color_map(vardata,'sheepWoolColors');dyes=color_map(vardata,'dyeColors')
    def render(spec):
        nonlocal stats
        entity=spec['entity'];model_id=spec['modelId'];layers=spec['layers']
        result=render_appearance(model_id,layers,jar,content)
        fam=stats['families'].setdefault(spec['family'],{'requested':0,'supported':0,'unsupported':0})
        fam['requested']+=1
        record={'entityType':entity.split(':')[1].upper(),'modelId':model_id,'conditions':spec['conditions'],
                'display':dict(GLOBAL_DISPLAY),'supported':bool(result['supported']),
                'limitations':spec.get('limitations',[])}
        if result['supported']:
            stats['cubes']+=result['cubeCount'];stats['faces']+=result['faceCount'];stats['pngs']+=result['pngCount'];stats['bytes']+=result['bytes'];stats['rotations']+=result['rotationCount']
            unique_pngs.update(result['uniquePngs'])
            record['limitations']=list(record['limitations'])+[GLOBAL_LIMITATION]
            items.append(f"{model_id.split(':')[1]}:\n  material: PAPER\n  model: {model_id.split(':')[1]}")
            fam['supported']+=1
            checks[model_id.split(':')[1]]={'status':'passed','evidence':result['evidence'],'cubes':result['cubeCount'],
                'faces':result['faceCount'],'pngs':result['pngCount'],'elementRotations':result['rotationCount'],
                'layers':result['layerCount'],'overlays':result['overlayKeys'],'bytes':result['bytes'],'family':spec['family']}
        else:
            reason=result['reason'];record['limitations']=record['limitations']+[reason]
            variant_failures.append({'modelId':model_id,'entityType':record['entityType'],'family':spec['family'],
                                     'stage':result['stage'],'category':result['category'],'reason':reason,'limitations':record['limitations']})
            fam['unsupported']+=1
            checks[model_id.split(':')[1]]={'status':'failed','stage':result['stage'],'evidence':reason,'family':spec['family']}
        variant_records.append(record)
        return result

    supported_defaults={'minecraft:'+m['entityType'].lower() for m in catalog['models'] if m['supported']}
    # ---- babies -----------------------------------------------------------------
    for entity in sorted(supported_defaults):
        raw=entries[entity];name=entity.split(':')[1]
        if entity in recipe.get('composites',{}):
            not_covered.append({'entityType':name.upper(),'variant':'baby','reason':'Adult composite clothing recipe does not cover the official baby clothing; excluded explicitly'})
            continue
        if name in ('camel_husk','zombie_nautilus','slime','sulfur_cube','creaking','frog','tropical_fish'):
            not_covered.append({'entityType':name.upper(),'variant':'baby','reason':'No distinct official baby model/texture for this entity'})
            continue
        baby=find_renderer_model(raw,'babyModel') or find_renderer_model(raw,'models.NORMAL.babyModel')
        base_tex=norm_texture(recipe.get('textureOverrides',{}).get(entity) or raw.get('texture'))
        baby_tex=derive_baby_texture(entity,base_tex)
        if baby is None or not baby_tex or not jar_has(jar,baby_tex):
            not_covered.append({'entityType':name.upper(),'variant':'baby','reason':'Official baby model or baby texture not found'})
            continue
        overlays=[]
        if name=='sheep':
            wool=find_layer_model(raw,'minecraft:sheep_baby#wool','babyModel')
            wt='textures/entity/sheep/sheep_wool_baby.png'
            if wool is None or not jar_has(jar,wt):
                not_covered.append({'entityType':'SHEEP','variant':'baby','reason':'Official baby wool layer not found'});continue
            overlays=[('wool',wool['tree'],wt,prepared['sheep_wool_baby_white']['bytes'])]
        spec={'entity':entity,'family':'baby','modelId':f'{NS}:{name}_baby',
              'conditions':conditions_for(entity,recipe,'baby'),'limitations':[GLOBAL_BABY],
              'layers':make_layers(baby['tree'],baby_tex,overlays=overlays)}
        render(spec)
    # ---- climate ----------------------------------------------------------------
    climate=[('minecraft:cow','warm','models.WARM'),('minecraft:cow','cold','models.COLD'),
             ('minecraft:pig','warm','models.NORMAL'),('minecraft:pig','cold','models.COLD'),
             ('minecraft:chicken','warm','models.NORMAL'),('minecraft:chicken','cold','models.COLD')]
    for entity,variant,model_prefix in climate:
        raw=entries[entity];name=entity.split(':')[1]
        adult=find_renderer_model(raw,model_prefix+'.adultModel');baby=find_renderer_model(raw,model_prefix+'.babyModel')
        data=data_variant(entity,variant);atex=asset_texture(data.get('asset_id'));btex=asset_texture(data.get('baby_asset_id'))
        if adult is None or not atex or not jar_has(jar,atex):
            not_covered.append({'entityType':name.upper(),'variant':variant,'reason':'Official climate model or texture not found'});continue
        render({'entity':entity,'family':'climate','modelId':f'{NS}:{name}_{variant}_adult',
                'conditions':conditions_for(entity,recipe,'adult',variant=f'minecraft:{variant}'),
                'limitations':['Climate-specific official model layer and texture.'],
                'layers':make_layers(adult['tree'],atex)})
        if baby is not None and btex and jar_has(jar,btex):
            render({'entity':entity,'family':'climate','modelId':f'{NS}:{name}_{variant}_baby',
                    'conditions':conditions_for(entity,recipe,'baby',variant=f'minecraft:{variant}'),
                    'limitations':[GLOBAL_BABY,'Climate-specific official baby model layer and texture.'],
                    'layers':make_layers(baby['tree'],btex)})
    for entity,variant in [('minecraft:frog','warm'),('minecraft:frog','cold')]:
        raw=entries[entity];name=entity.split(':')[1];tex=f'textures/entity/frog/frog_{variant}.png'
        if jar_has(jar,tex):
            render({'entity':entity,'family':'climate','modelId':f'{NS}:{name}_{variant}_adult',
                    'conditions':conditions_for(entity,recipe,'adult',variant=f'minecraft:{variant}'),
                    'limitations':['Climate-specific official texture on the shared frog model.'],
                    'layers':make_layers(raw['base']['tree'],tex)})
    if 'minecraft:zombie_nautilus' in supported_defaults:
        raw=entries['minecraft:zombie_nautilus'];warm=find_renderer_model(raw,'models.WARM')
        tex='textures/entity/nautilus/zombie_nautilus_coral.png'
        if warm and jar_has(jar,tex):
            render({'entity':'minecraft:zombie_nautilus','family':'climate','modelId':f'{NS}:zombie_nautilus_warm_adult',
                    'conditions':conditions_for('minecraft:zombie_nautilus',recipe,'adult',variant='minecraft:warm'),
                    'limitations':['Warm/coral official model layer and texture.'],
                    'layers':make_layers(warm['tree'],tex)})
    # ---- villager types, professions, levels, and official hat selection -------
    villager=entries['minecraft:villager'];villager_tree,pose_notes=apply_pose_override('minecraft:villager',villager['base']['tree'],recipe)
    for appearance in villager_appearances:
        name=appearance['name'];village_type=appearance['type'];profession=appearance['profession'];level=appearance['level']
        render({'entity':'minecraft:villager','family':'villager','modelId':f'{NS}:{name}',
            'conditions':conditions_for('minecraft:villager',recipe,'adult',variant=f'minecraft:{village_type}',
                villagerType=village_type,profession=profession,professionLevel=level,heldItem='none',unhappy=False),
            'limitations':['Adult static villager appearance; sleeping, working, trading, held items and baby rendering are excluded.',
                f"Official type layer uses the {appearance['typeModel']} model from type hat={appearance['typeHat']} and profession hat={appearance['professionHat']} metadata; profession and level layers use the full parent model.",
                'Official base, type, profession and applicable level cutout passes are composited in renderer order without coincident cubes.']+pose_notes,
            'layers':make_layers(villager_tree,'textures/entity/villager/villager.png',data=prepared[name]['bytes'])})
    # ---- sheep colours and sheared ---------------------------------------------
    sheep=entries['minecraft:sheep'];adult=sheep['base'];wool=find_layer_model(sheep,'minecraft:sheep#wool','adultModel')
    base_tex='textures/entity/sheep/sheep.png';wool_tex='textures/entity/sheep/sheep_wool.png'
    for color,argb in wools.items():
        if color=='white':continue
        render({'entity':'minecraft:sheep','family':'colour','modelId':f'{NS}:sheep_{color}_adult',
                'conditions':conditions_for('minecraft:sheep',recipe,'adult',color=color,sheared=False,jeb=False),
                'limitations':[f'Official sheep wool colour multiplier baked into the PNG; alpha preserved.'],
                'layers':make_layers(adult['tree'],base_tex,overlays=[('wool',wool['tree'],wool_tex,prepared['sheep_wool_'+color]['bytes'])] if wool else [])})
    render({'entity':'minecraft:sheep','family':'colour','modelId':f'{NS}:sheep_adult_sheared',
            'conditions':conditions_for('minecraft:sheep',recipe,'adult',sheared=True,jeb=False,color=None),
            'limitations':['Sheared sheep has no wool layer; colour is intentionally unconstrained because the sheared body is the same for every dye.'],
            'layers':make_layers(adult['tree'],base_tex)})
    # ---- llama colours ----------------------------------------------------------
    for entity in ('minecraft:llama','minecraft:trader_llama'):
        raw=entries[entity];name=entity.split(':')[1]
        for color in ('white','brown','gray'):
            tex=f'textures/entity/llama/llama_{color}.png'
            if not jar_has(jar,tex):continue
            render({'entity':entity,'family':'colour','modelId':f'{NS}:{name}_{color}_adult',
                    'conditions':conditions_for(entity,recipe,'adult',variant=f'minecraft:{color}',color=color,decor='none',saddle=False),
                    'limitations':[f'Official llama colour texture {color}.'],
                    'layers':make_layers(raw['base']['tree'],tex)})
    # ---- rabbit variants --------------------------------------------------------
    rabbit=entries['minecraft:rabbit']
    for variant in vardata['rabbitVariants']:
        if variant=='brown':continue
        tex=f'textures/entity/rabbit/rabbit_{variant}.png'
        if not jar_has(jar,tex):continue
        render({'entity':'minecraft:rabbit','family':'variety','modelId':f'{NS}:rabbit_{variant}_adult',
                'conditions':conditions_for('minecraft:rabbit',recipe,'adult',variant=f'minecraft:{variant}'),
                'limitations':[f'Official rabbit variant texture {variant}.'],
                'layers':make_layers(rabbit['base']['tree'],tex)})
    # ---- panda genes ------------------------------------------------------------
    panda=entries['minecraft:panda']
    for gene in vardata['pandaGenes']:
        if gene=='normal':continue
        tex=f'textures/entity/panda/panda_{gene}.png'
        if not jar_has(jar,tex):continue
        render({'entity':'minecraft:panda','family':'variety','modelId':f'{NS}:panda_{gene}_adult',
                'conditions':conditions_for('minecraft:panda',recipe,'adult',variant=f'minecraft:{gene}',heldItem='none'),
                'limitations':[f'Official panda gene texture {gene}.'],
                'layers':make_layers(panda['base']['tree'],tex)})
    # ---- tropical fish patterns -------------------------------------------------
    fish=entries['minecraft:tropical_fish'];large=find_renderer_model(fish,'largeModel')
    patterns={p['name']:p for p in vardata['fishPatterns']}
    for pname,p in patterns.items():
        if pname==vardata['fishDefaultPattern']:continue
        shape='small' if p['base']=='SMALL' else 'large';bodychar='a' if shape=='small' else 'b'
        body_tree=fish['base']['tree'] if shape=='small' else (large['tree'] if large else None)
        layer=find_layer_model(fish,'minecraft:tropical_fish_small#pattern','modelSmall') if shape=='small' else find_layer_model(fish,'minecraft:tropical_fish_large#pattern','modelLarge')
        if body_tree is None or layer is None:continue
        btex=f'textures/entity/fish/tropical_{bodychar}.png';ptex=f'textures/entity/fish/tropical_{bodychar}_pattern_{p["packedId"]%6+1}.png'
        body_tint=prepared['fish_body_'+shape]['bytes'];pattern_tint=prepared['fish_pattern_'+shape+'_'+pname]['bytes']
        render({'entity':'minecraft:tropical_fish','family':'variety','modelId':f'{NS}:tropical_fish_{shape}_{pname}_white_white_adult',
                'conditions':conditions_for('minecraft:tropical_fish',recipe,'adult',shape=shape,pattern=pname,baseColor='white',patternColor='white'),
                'limitations':['Official small/large tropical-fish body and pattern layers, tinted with the official white dye colour.'],
                'layers':make_layers(body_tree,btex,data=body_tint,overlays=[('pattern',layer['tree'],ptex,pattern_tint)])})
    # ---- explicit unsupported variant -------------------------------------------
    not_covered.append({'entityType':'SHEEP','variant':'jeb','reason':'jeb_ sheep continuously cycles a rainbow hue; a static embedded PNG cannot represent it'})
    variant_records.append({'entityType':'SHEEP','modelId':f'{NS}:sheep_adult_jeb','conditions':conditions_for('minecraft:sheep',recipe,'adult',jeb=True,color=None),
        'display':dict(GLOBAL_DISPLAY),'supported':False,'limitations':['jeb_ rainbow animation is not representable by a static model.']})
    variant_failures.append({'modelId':f'{NS}:sheep_adult_jeb','entityType':'SHEEP','family':'colour','stage':'policy','category':'policy','reason':'jeb_ sheep continuously cycles a rainbow hue; a static embedded PNG cannot represent it','limitations':[]})
    checks['sheep_adult_jeb']={'status':'failed','stage':'policy','evidence':'jeb_ rainbow animation is not representable by a static model.'}

    # ---- merge catalog/report ---------------------------------------------------
    catalog['models'].extend(variant_records)
    (content/'items/mobs.yml').write_text('\n'.join(sorted(items))+'\n')
    supported=[m for m in catalog['models'] if m['supported']];unsupported=[m for m in catalog['models'] if not m['supported']]
    supported_entities={m['entityType'] for m in supported};variant_entities={r['entityType'] for r in variant_records if r['supported']}
    by_category={}
    for x in variant_failures:by_category.setdefault(x.get('category','unsupported'),[]).append(x['entityType'].lower())
    report['assetVersion']='0.3.4';report['requestedModelCount']=len(catalog['models'])
    report['defaultModelCount']=defaults_report['requestedModelCount'];report['defaultSuccessCount']=defaults_report['successCount']
    report['variantRequestedCount']=len(variant_records);report['variantSuccessCount']=sum(1 for r in variant_records if r['supported'])
    report['variantUnsupportedCount']=len(variant_records)-report['variantSuccessCount']
    report['successCount']=len(supported);report['modelCount']=len(supported);report['unsupportedCount']=len(unsupported)
    report['cubeCount']=defaults_report['cubeCount']+stats['cubes'];report['faceCount']=defaults_report['faceCount']+stats['faces']
    report['pngCount']=defaults_report['pngCount']+stats['pngs'];report['embeddedPngCount']=report['pngCount']
    report['uniquePngCount']=len(unique_pngs|set())
    existing_unsupported=report.get('unsupported',[])
    all_unsupported=existing_unsupported+variant_failures
    report['successes']=[m['modelId'] for m in supported]
    report['failures']=all_unsupported
    report['unsupported']=all_unsupported
    report['geometryIssues']=report['geometryIssues']+[x for x in variant_failures if x['category']=='orientation']
    report['uvIssues']=report['uvIssues']+[x for x in variant_failures if x['category']=='uv']
    by_category={}
    for x in all_unsupported:by_category.setdefault(x.get('category','policy'),[]).append(x['entityType'].lower())
    report['unsupportedByCategory']=by_category
    report['coverage']={'candidateEntityCount':defaults_report['coverage']['candidateEntityCount'],
        'defaultSupportedEntityCount':defaults_report['successCount'],'supportedEntityCount':len(supported_entities),
        'variantSupportedEntityCount':len(variant_entities),'unsupportedEntityCount':defaults_report['coverage']['unsupportedEntityCount'],
        'extractionFailureCount':defaults_report['extractionFailureCount'],'unverifiedEntityCount':0,
        'successPercent':round(100*len(supported)/len(catalog['models']),2),
        'entitySuccessPercent':round(100*len(supported_entities)/defaults_report['coverage']['candidateEntityCount'],2)}
    report['variantFamilies']=stats['families']
    report['notCoveredVariants']=not_covered+[
        {'entityType':'WOLF','variant':'all','reason':'Base adult default pose contains non-representable rotations; no wolf variant is emitted.'},
        {'entityType':'CAT','variant':'all','reason':'Base adult default pose contains non-representable rotations; no cat variant is emitted.'},
        {'entityType':'HORSE','variant':'all','reason':'Base adult default pose contains non-representable rotations; no horse variant is emitted.'},
        {'entityType':'TROPICAL_FISH','variant':'colour','reason':'Only white/white colour combinations are covered; the remaining base/pattern colour pairs are not emitted.'},
        {'entityType':'RABBIT','variant':'baby','reason':'Baby rabbit variants are not yet covered.'},
        {'entityType':'PANDA','variant':'baby','reason':'Baby panda genes are not yet covered.'},
        {'entityType':'LLAMA','variant':'baby','reason':'Baby llama colours are not yet covered.'},
        {'entityType':'SHEEP','variant':'baby_colour','reason':'Baby sheep colours beyond white are not yet covered.'}]
    villager_policy=recipe['villagerVariants'];all_types={x.split(':',1)[1] for x in vardata['villagerTypes']};all_levels={x['level'] for x in vardata['villagerLevels']}
    omitted_types=sorted(all_types-set(villager_policy['types']));omitted_levels=sorted(all_levels-set(villager_policy['levels']))
    if omitted_types:report['notCoveredVariants'].append({'entityType':'VILLAGER','variant':'villager_type','reason':'Dance-focused set covers plains only; omitted official types: '+', '.join(omitted_types)})
    if omitted_levels:report['notCoveredVariants'].append({'entityType':'VILLAGER','variant':'profession_level','reason':'Dance-focused set covers profession level 1 only; omitted badge levels: '+', '.join(map(str,omitted_levels))})
    report['tests']['models']=checks
    report['tests']['variants']={'status':'passed' if not variant_failures else 'partial',
        'requested':len(variant_records),'supported':report['variantSuccessCount'],'unsupported':report['variantUnsupportedCount'],
        'evidence':f'{report["variantSuccessCount"]} variant bbmodels passed the real BbModel converter and official geometry/UV/PNG checks; failures are listed with exact reasons'}
    report['rpEngineCompatibility']['actualConverter']=f'passed for {len(supported)} supported models'
    report['rpEngineCompatibility']['elementRotationCount']=sum(v.get('elementRotations',0) for v in checks.values() if v['status']=='passed')
    # Count unique textures over every delivered model.
    unique_hashes=set()
    for p in content.rglob('*.bbmodel'):
        try:data=json.loads(p.read_text())
        except Exception:continue
        for t in data.get('textures',[]):
            unique_hashes.add(hashlib.sha256(base64.b64decode(t['source'].split(',',1)[1])).hexdigest())
    report['uniquePngCount']=len(unique_hashes)
    report['assets']={'bbmodelBytes':sum(p.stat().st_size for p in content.rglob('*.bbmodel')),
        'contentBytes':sum(p.stat().st_size for p in content.rglob('*') if p.is_file())}
    # version + manifest
    (content/'pack.yml').write_text('name: Vanilla Mobs\nversion: 0.3.4\nbundles: [main]\n')
    dump(dist/'catalog.json',catalog);dump(dist/'report.json',report)
    files=[]
    for p in sorted(content.rglob('*')):
        if p.is_file():files.append({'path':p.relative_to(dist).as_posix(),'sha256':sha(p),'size':p.stat().st_size})
    dump(dist/'manifest.json',{'schema':1,'minecraftVersion':recipe['minecraftVersion'],'namespace':NS,'assetVersion':'0.3.4',
        'sourceClientSha1':report['sourceClientSha1'],'catalogSha256':sha(dist/'catalog.json'),'files':files})
    print(json.dumps({'defaults':defaults_report['successCount'],'variants':report['variantSuccessCount'],
        'variantUnsupported':report['variantUnsupportedCount'],'models':len(catalog['models']),
        'cubes':report['cubeCount'],'faces':report['faceCount'],'pngs':report['pngCount'],
        'contentBytes':report['assets']['contentBytes']}),flush=True)
    return report

if __name__=='__main__':
    build_variants(pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'dist'))
