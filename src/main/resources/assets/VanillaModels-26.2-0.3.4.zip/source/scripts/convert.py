#!/usr/bin/env python3
"""Bake verified ModelPart polygons into RP Engine cubes, losslessly or not at all.

The official model tree is transformed to the delivery coordinate system first.
Every cube's linear transform is then decomposed into

    world = translate(center) . allowed_element_rotation . signed_permutation . scale

`allowed_element_rotation` is one of the five rotations RP Engine's BbModel
converter can actually represent (single axis, 0/+-22.5/+-45 degrees).  A
signed permutation (axis swap / mirror / cardinal rotation) is baked into the
cube's from/to box and face mapping, which is lossless.  Any other orientation,
shear, non-rectangular UV, or unsupported face is rejected instead of snapped.
"""
import base64,hashlib,itertools,json,math,pathlib,struct,sys,uuid,zipfile

class Unsupported(ValueError): pass

# Official model units -> delivered item-model space (same convention as 0.1.0).
BB = [[-0.4,0.0,0.0,8.0],[0.0,-0.4,0.0,17.6],[0.0,0.0,0.4,8.0],[0.0,0.0,0.0,1.0]]
D3 = [[-1.0,0.0,0.0],[0.0,-1.0,0.0],[0.0,0.0,1.0]]
ALLOWED_ANGLES = (0.0,22.5,-22.5,45.0,-45.0)

def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
def eye(): return [[int(i==j) for j in range(4)] for i in range(4)]
def mul(a,b): return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]
def mul3(a,b): return [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
def matrix(p):
    m=eye()
    for i,a in enumerate('xyz'): m[i][3]=p.get(a,0)
    for axis,a in reversed(list(enumerate('xyz'))):
        r=eye(); c=math.cos(p.get(a+'Rot',0)); s=math.sin(p.get(a+'Rot',0)); i,j=((1,2),(2,0),(0,1))[axis]
        r[i][i]=r[j][j]=c; r[i][j]=-s; r[j][i]=s; m=mul(m,r)
    s=eye()
    for i,a in enumerate('xyz'): s[i][i]=p.get(a+'Scale',1)
    return mul(m,s)
def transform(m,v): return [sum(m[i][j]*v[j] for j in range(3))+m[i][3] for i in range(3)]
def transform4(m,v): return [sum(m[i][j]*v[j] for j in range(3))+m[i][3] for i in range(3)]
def vec3(m,v): return transform4(m,v)
def close(a,b,tol=1e-5): return all(abs(x-y)<tol for x,y in zip(a,b))
def nearly(a,b,tol=2e-4): return all(abs(x-y)<tol for x,y in zip(a,b))

# --- orientation decomposition -------------------------------------------------
def _signed_permutations():
    out=[]
    for perm in itertools.permutations(range(3)):
        for signs in itertools.product((1,-1),repeat=3):
            m=[[0]*3 for _ in range(3)]
            for row,col in enumerate(perm): m[row][col]=signs[row]
            out.append(m)
    return out
SIGNED_PERMUTATIONS=_signed_permutations()

def _axis_rotation(axis,degrees):
    a=math.radians(degrees); c=math.cos(a); s=math.sin(a); m=[[0.0]*3 for _ in range(3)]
    i,j=((1,2),(2,0),(0,1))[axis]
    m[i][i]=c; m[j][j]=c; m[i][j]=-s; m[j][i]=s
    k=3-i-j; m[k][k]=1.0
    return m

ALLOWED_ROTATIONS=[(axis,deg,_axis_rotation(axis,deg)) for axis in range(3) for deg in ALLOWED_ANGLES]

def decompose(rotation):
    """Return (signed_permutation, axis, degrees) for R = A(axis,deg) * P.

    Cardinal angles are folded into P.  Every multiple of 22.5 degrees is
    representable because at most 45 degrees remain after folding the nearest
    cardinal rotation, but arbitrary angles are not.
    """
    for axis,deg,rot in ALLOWED_ROTATIONS:
        for perm in SIGNED_PERMUTATIONS:
            if all(abs(rotation[i][j]-sum(rot[i][k]*perm[k][j] for k in range(3)))<2e-4
                   for i in range(3) for j in range(3)):
                return perm,axis,deg
    return None

def _linear(m): return [[m[i][j] for j in range(3)] for i in range(3)]
def _apply3(m,v): return [sum(m[i][j]*v[j] for j in range(3)) for i in range(3)]

def _decompose_cube(local_points, m_bb, faces):
    """Classify one cube. Returns (from,to,axis,deg,origin,point_fn,normal_fn)."""
    lo=[min(p[i] for p in local_points) for i in range(3)]
    hi=[max(p[i] for p in local_points) for i in range(3)]
    center=[(lo[i]+hi[i])/2 for i in range(3)]
    c=vec3(m_bb,center)
    a=_linear(m_bb)
    cols=[_apply3(a,[1.0 if i==j else 0.0 for j in range(3)]) for i in range(3)]
    lens=[math.sqrt(sum(x*x for x in col)) for col in cols]
    for i in range(3):
        if lens[i]<1e-9: continue
        for j in range(i+1,3):
            if lens[j]<1e-9: continue
            dot=sum(cols[i][k]*cols[j][k] for k in range(3))/(lens[i]*lens[j])
            if abs(dot)>3e-4: raise Unsupported('Sheared cube geometry (non-orthogonal cube axes)')
    rotation=[[0.0]*3 for _ in range(3)]
    known=[]
    for i in range(3):
        if lens[i]>1e-9:
            for k in range(3): rotation[k][i]=cols[i][k]/lens[i]
            known.append(i)
    if len(known)<3:
        for i in range(3):
            if i not in known:
                for k in range(3): rotation[k][i]=1.0 if k==i else 0.0
    dec=decompose(rotation)
    if dec is None:
        raise Unsupported('Non-representable orientation: RP Engine element rotations are single-axis 0/+-22.5/+-45 degrees')
    perm,axis,deg=dec
    arot=_axis_rotation(axis,deg)
    # q = Arot^-1 . (world - center) is the unrotated cube box.
    qpts=[_apply3([row[:] for row in zip(*arot)], [p[i]-c[i] for i in range(3)]) for p in [vec3(m_bb,v) for v in local_points]]
    half=[max(abs(p[i]) for p in qpts) for i in range(3)]
    frm=[round(c[i]-half[i],6) for i in range(3)]
    to=[round(c[i]+half[i],6) for i in range(3)]
    def pt(p):
        w=vec3(m_bb,p)
        d=[w[i]-c[i] for i in range(3)]
        return _apply3([row[:] for row in zip(*arot)],d)
    def nrm(n):
        return [sum(perm[j][i]*n[i] for i in range(3)) for j in range(3)]
    return frm,to,axis,deg,c,pt,nrm

def uv_face(points,normal,lo,hi,layout,width,height,slot):
    axis=max(range(3),key=lambda i:abs(normal[i])); unit=[0,0,0]; unit[axis]=1 if normal[axis]>0 else -1
    norm=math.sqrt(sum(x*x for x in normal))
    if not norm or not close([x/norm for x in normal],unit,1e-5):
        raise Unsupported('Non-axis-aligned normal; RP Engine rotation snapping would lose geometry')
    face=(('west','east'),('down','up'),('north','south'))[axis][normal[axis]>0]
    candidates=[]
    for bits in layout[face]:
        pos=[(lo,hi)[bits[i]][i] for i in range(3)]
        matches=[i for i,(v,uv) in enumerate(points) if close(v,pos)]
        if not matches: raise Unsupported('Not an exact cuboid face: '+face)
        candidates.append(matches)
    # A zero-thickness cube makes two corners share a position.  Enumerate the
    # (at most 16) assignments and keep one that uses each vertex once and forms
    # a rectangle expressible by RP Engine face UV rotation.
    for combo in itertools.product(*candidates):
        if len(set(combo))!=4: continue
        ordered=[[points[i][1][0]*width,points[i][1][1]*height] for i in combo]
        us=sorted(set(round(p[0],6) for p in ordered)); vs=sorted(set(round(p[1],6) for p in ordered))
        if len(us)>2 or len(vs)>2: continue
        for u in (us,us[::-1]):
            for v in (vs,vs[::-1]):
                for turn in range(4):
                    predicted=[[u[0]+(u[-1]-u[0])*layout['uv'][(i+turn)%4][0],
                                v[0]+(v[-1]-v[0])*layout['uv'][(i+turn)%4][1]] for i in range(4)]
                    if all(close(a,b) for a,b in zip(predicted,ordered)):
                        return face,{'uv':[u[0],v[0],u[-1],v[-1]],'rotation':turn*90,'texture':slot}
    raise Unsupported('Cannot express UV orientation')

def flatten(p,parent=None,path='root',m_bb=None):
    m=mul(parent if parent is not None else eye(),matrix(p))
    if not p.get('visible',True): return
    if not p.get('skipDraw',False):
        for index,faces in enumerate(p['cubes']):
            yield path+'/'+str(index),faces,m
    for name,child in sorted(p['children'].items()): yield from flatten(child,m,path+'/'+name)

def convert(name,layers,archive,rawdir,texture_overrides=None):
    """Convert official layer trees into one RP Engine bbmodel.

    layers entries are (layer_key, texture_path) or dicts with layer, texture,
    and optional data bytes. texture_overrides maps layer keys or texture paths
    to already-processed PNG bytes.
    """
    layout=json.loads((rawdir/'face-layout.json').read_text()); elements=[]; textures=[]; hashes={}; layer_textures={}
    overrides=texture_overrides or {}
    for entry in layers:
        if isinstance(entry,dict):
            layer=entry['layer'];texture=entry['texture'];data=entry.get('data')
        else:
            layer,texture=entry;data=None
        if data is None: data=overrides.get(layer,overrides.get(texture))
        if data is None and layer=='sheep_wool':
            legacy=rawdir/'sheep_wool_tinted.png'
            if legacy.exists(): data=legacy.read_bytes()
        if data is None:
            data=archive.read('assets/minecraft/'+texture)
        if not data.startswith(b'\x89PNG\r\n\x1a\n'): raise Unsupported('Not PNG: '+str(texture))
        w,h=struct.unpack('>II',data[16:24]); digest=hashlib.sha256(data).hexdigest()
        if digest not in hashes:
            hashes[digest]=len(textures)
            textures.append({'name':pathlib.Path(texture).name,'id':str(len(textures)),
                             'uuid':str(uuid.uuid5(uuid.NAMESPACE_URL,digest)),
                             'uv_width':w,'uv_height':h,
                             'source':'data:image/png;base64,'+base64.b64encode(data).decode()})
        slot=hashes[digest]; layer_textures[layer]=pathlib.Path(texture).name
        tree_path=rawdir/(layer+'.json')
        if not tree_path.exists(): raise Unsupported('Missing extracted layer: '+layer)
        root=next(iter(json.loads(tree_path.read_text()).values()))
        for path,faces,m in flatten(root,None,'root'):
            try:
                m_bb=mul(BB,m)
                local=[v[:3] for f in faces for v in f['vertices']]
                if not local: raise Unsupported('Cube without geometry')
                frm,to,axis,deg,origin,pt,nrm=_decompose_cube(local,m_bb,faces)
                if any(to[i]-frm[i]<-1e-6 for i in range(3)): raise Unsupported('Invalid decomposed box')
                out={}
                for f in faces:
                    qp=[([pt(v[:3])[i]+origin[i] for i in range(3)],v[3:]) for v in f['vertices']]
                    face,uv=uv_face(qp,nrm(f['normal']),frm,to,layout,w,h,slot)
                    if face in out: raise Unsupported('Duplicate cube face')
                    out[face]=uv
                element={'type':'cube','name':layer+'/'+path,
                         'uuid':str(uuid.uuid5(uuid.NAMESPACE_URL,name+'/'+layer+'/'+path)),
                         'from':frm,'to':to,'faces':out,'box_uv':False}
                if deg:
                    element['rotation']={'origin':[round(x,6) for x in origin],'axis':'xyz'[axis],'angle':round(deg,6)}
                elements.append(element)
            except Unsupported as error:
                raise Unsupported(f'{layer}/{path}: {error}') from error
    if not elements: raise Unsupported('Empty model')
    return {'meta':{'format_version':'4.10','model_format':'java_block','box_uv':False},'name':name,
            'resolution':{'width':textures[0]['uv_width'],'height':textures[0]['uv_height']},
            'elements':elements,'textures':textures,'outliner':[e['uuid'] for e in elements],'layer_textures':layer_textures}

if __name__=='__main__':
    raw=pathlib.Path(sys.argv[1]); target=pathlib.Path(sys.argv[2])
    with zipfile.ZipFile(sys.argv[3]) as z: model=convert('cow_adult',[('cow','textures/entity/cow/cow_temperate.png')],z,raw)
    dump(target,model); print('Converted cow:',len(model['elements']),'cubes')
