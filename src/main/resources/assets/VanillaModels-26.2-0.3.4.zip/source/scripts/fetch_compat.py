import pathlib,urllib.request,hashlib
root=pathlib.Path(__file__).resolve().parents[1]
revision='5454b685cceccfd291a8345da84a4c49441c2773'
for source,target in [('src/main/java/ai/resourcepack/engine/core/item/BbModel.java','BbModel.java'),('LICENSE','LICENSE')]:
 p=root/'.cache/rp-compat'/target;p.parent.mkdir(parents=True,exist_ok=True)
 if source.endswith('.java') and p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==(root/'docs/rp-bbmodel.sha256').read_text().strip():continue
 if source=='LICENSE' and p.exists():continue
 data=urllib.request.urlopen(f'https://raw.githubusercontent.com/resourcepack-ai/rp-engine/{revision}/{source}',timeout=60).read()
 if source.endswith('.java'):
  expected=(root/'docs/rp-bbmodel.sha256').read_text().strip()
  assert hashlib.sha256(data).hexdigest()==expected,'Upstream source checksum mismatch'
 p.write_bytes(data)
