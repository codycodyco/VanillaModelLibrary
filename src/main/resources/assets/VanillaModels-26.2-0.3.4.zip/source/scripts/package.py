#!/usr/bin/env python3
"""Deterministic two-build gate, real repeat extraction, and private ZIP."""
import pathlib,json,shutil,subprocess,hashlib,zipfile,os,sys
from build_variants import build_variants
from build_assets import ROOT,sha,cp,java_bin
from convert import dump
from validate import validate

def inventory(folder):
    return {p.relative_to(folder).as_posix():sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}
def archive(path,folder):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(folder.rglob('*')):
            if p.is_file():
                entry=zipfile.ZipInfo('dist/'+p.relative_to(folder).as_posix(),date_time=(2026,1,1,0,0,0))
                entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100644<<16
                z.writestr(entry,p.read_bytes())
        extras=[]
        for base in ['docs','schemas','scripts','tests','src','gradle','recipes']:
            extras.extend((p,'source/'+p.relative_to(ROOT).as_posix()) for p in (ROOT/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.DS_Store' not in p.parts)
        extras.extend((ROOT/n,'source/'+n) for n in ['README.md','LICENSE','.gitignore','.gitattributes','build.gradle','settings.gradle','gradlew','gradlew.bat'])
        inv=ROOT/'.cache/all-raw/inventory.json'
        if inv.exists():extras.append((inv,'evidence/inventory.json'))
        for name in ['server-test.log','server-result.json','gradle-result.json']:
            if (ROOT/'build'/name).exists():extras.append((ROOT/'build'/name,'evidence/'+name))
        for p,name in sorted(extras,key=lambda x:x[1]):
            entry=zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0))
            entry.compress_type=zipfile.ZIP_DEFLATED
            entry.external_attr=(0o100755 if p.name=='gradlew' or p.suffix=='.sh' else 0o100644)<<16
            z.writestr(entry,p.read_bytes())
        entry=zipfile.ZipInfo('source/COMMIT.txt',date_time=(2026,1,1,0,0,0))
        z.writestr(entry,os.environ.get('SOURCE_COMMIT','unrecorded')+'\n')
def raw_inventory(folder):
    return {p.relative_to(folder).as_posix():sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}
def main():
    subprocess.run(['python3','-m','unittest','discover','-s','tests','-v'],cwd=ROOT,check=True)
    a=ROOT/'build/repeat-a';b=ROOT/'build/repeat-b'
    for p in (a,b):
        if p.exists():shutil.rmtree(p)
        build_variants(p);validate(p)
    artifact_env=dict(os.environ);artifact_env['VANILLA_TEST_DIST']=str(a)
    subprocess.run(['python3','-m','unittest','discover','-s','tests','-v'],cwd=ROOT,env=artifact_env,check=True)
    assert inventory(a)==inventory(b),'Nondeterministic asset build'
    # Re-run the complete official registry extraction; every entity JSON and the
    # inventory must be byte-identical.
    repeat=ROOT/'.cache/all-raw-repeat'
    if repeat.exists():shutil.rmtree(repeat)
    subprocess.run([java_bin(),'-Xmx2G','-cp',cp(),'extractor.ExtractAll',str(repeat),str(ROOT/'.cache/client.jar')],check=True,stdout=subprocess.DEVNULL)
    original=raw_inventory(ROOT/'.cache/all-raw');again=raw_inventory(repeat)
    assert original==again,'Nondeterministic official extraction'
    report=json.loads((a/'report.json').read_text())
    report['sourceCommit']=os.environ.get('SOURCE_COMMIT','unrecorded')
    report['tests']['pythonTests']={'status':'passed','evidence':'python3 -m unittest discover -s tests -v; repeated against actual packaged dist (curated villager set, explicit dance-pose recipes, overlay bind poses, registration, and prior-model regression checks)'}
    report['tests']['schemaAndHashes']={'status':'passed','evidence':'Strict schema-1, all catalog records (registry defaults + variants), supported/unsupported file+registration boundary, all install hashes/sizes, catalog hash'}
    report['tests']['determinism']={'status':'passed','evidence':'Two complete default+variant asset builds byte-identical; repeated official ExtractAll byte-identical for inventory and all entity JSON; deterministic ZIP compared twice'}
    gradle=ROOT/'build/gradle-result.json'
    if gradle.exists():report['tests']['gradleBuild']=json.loads(gradle.read_text())
    server=ROOT/'build/server-result.json'
    if server.exists():
        evidence=json.loads(server.read_text());installed=evidence.pop('installedFiles',None)
        current={p.relative_to(a/'content/vanillamobs').as_posix():sha(p) for p in (a/'content/vanillamobs').rglob('*') if p.is_file()}
        if installed==current:
            report['tests']['server']=evidence
            report['rpEngineCompatibility']['serverBundleBuild']='passed on Paper 26.2-134 / RP Engine 0.2.20 (all supported ITEMs)'
    dump(a/'report.json',report);validate(a)
    target=ROOT/'dist'
    if target.exists():shutil.rmtree(target)
    shutil.copytree(a,target)
    name=f"VanillaModels-{report['minecraftVersion']}-{report['assetVersion']}.zip"
    archive(ROOT/name,target);archive(ROOT/'build/repeat.zip',target)
    assert sha(ROOT/name)==sha(ROOT/'build/repeat.zip'),'Nondeterministic ZIP'
    result={'zip':name,'zipSha256':sha(ROOT/name),'zipBytes':(ROOT/name).stat().st_size,
            'successCount':report['successCount'],'unsupportedCount':report['unsupportedCount'],
            'cubeCount':report['cubeCount'],'pngCount':report['pngCount'],
            'contentBytes':report['assets']['contentBytes']}
    (ROOT/'build/package-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
if __name__=='__main__':main()
