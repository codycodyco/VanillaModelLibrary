# Execution record — 2026-10-26

Environment: Ubuntu 5.15 x86_64 (host `cody-test`), Python 3.10,
JDK 25, Gradle 9.8.0. Builds and extraction ran on Ubuntu; the Mac only
received the final private ZIP. Official 26.2 client SHA-1
`2dc72797acbc1b63fc16a11c4ac393605f453754`.

## Actual counts

| Stage | Supported | Unsupported | Cubes | Faces | PNGs | Content bytes |
|---|---:|---:|---:|---:|---:|---:|
| defaults | 50 / 87 entities | 37 | 516 | 3,096 | 57 | 843,708 |
| defaults + variants | 136 / 181 records | 45 | 1,395 | 8,370 | 170 | 2,277,430 |

Unique embedded PNG SHA-256: 133. Default candidate registry: 158 entity
types, 358 official model layers, 71 exclusions, 87 candidates. Villager is
explicitly included although the official registry categorizes it as MISC.

## Executed commands

- `python3 scripts/prepare.py <official-client.jar>`: official SHA-1 and
  dependency verification (existing audited cache).
- `./gradlew --no-daemon --offline clean classes compatClasses check`:
  successful; Python 9 unit tests passed.
- `extractor.Extract` + `scripts/convert.py` + `extractor.Verify` cow gate.
- `extractor.ExtractAll .cache/all-raw .cache/client.jar`: 87 candidates,
  87 extracted, 0 extraction failures.
- `python3 scripts/build_variants.py build/quick-034`: 50 defaults and 86
  variants passed the real converter; 136 total supported.
- Per the delivery request, 0.3.4 skipped repeat-build, schema, ZIP
  determinism, and Paper/RP Engine server validation.
- Previous 0.3.3 run, `PAPER_SOURCE=... python3 scripts/server_test.py`: Paper 26.2-134 +
  RP Engine 0.2.20 started, `rp reload` ran, bundle `main.zip` contained and
  validated all 124 supported ITEM definitions, models and PNG references.
  Bundle SHA-256: `278b4297dd105daac1e5a69285d426d003a8872ee3b4d0dadeebf133b5420cc2`.

Villager verification additionally checks that the official `-0.75` radian
folded-arms source pose is unchanged in the extraction cache, the copied static
tree substitutes exactly `-pi/4`, and RP Engine emits exact 45-degree element
rotations. The 15-model plains profession set is checked against the official
type/profession registries. Base, type, profession, and level-1 textures are
composited in renderer order and independently checked pixel-by-pixel; official
hat metadata selects the full or no-hat type-layer mask. Every 0.3.2 bbmodel
remains byte-identical. Other villager types and badge levels 2–5 are listed in
`notCoveredVariants` and cannot match these models.
  `host.mode: none`, loopback only, no upload.

## Rejected examples

35 default entities and several variants are rejected because the official
default pose contains an orientation RP Engine cannot express as a single
axis `0/±22.5/±45°` element rotation. The report names the exact cube, e.g.
`main/root/left_arm/0`. Zombie is delivered from the official bind pose as an explicitly
permitted static replacement. The same documented dance-pose policy now covers
spiders, skeleton/zombie families, and piglin families. `EnderDragon` has no single
base texture; Mooshroom's mushroom overlay is block geometry. `jeb_` sheep
is an animated rainbow; baby rabbit has a non-exact cuboid face; zombie
nautilus warm has non-representable coral rotations.

## Not verified

The 12 newly supported 0.3.4 defaults have not been run through a Paper/RP
Engine server or checked in-client. Client visual alignment/lighting/transparent-edge rendering, shaders,
Bedrock, other Minecraft versions, equipment/animation, and colour
combinations not listed in `notCoveredVariants`. These remain explicitly
unverified in `dist/report.json`.
