# Reference audit

FriendsWinePlugin revision c613b45a7ad8093824c88a4bc1f3b760fc65377b:
VanillaModelExporter.java and build_models.py were read. No repository license
was found. No source code was copied. The useful approach is to invoke official
layer builders, inspect their baked vertices, and preserve texture coordinates.
Its mesh output is not used here.

RP Engine revision 5454b685cceccfd291a8345da84a4c49441c2773 is GPL-3.0-or-later.
FORMAT.md, BbModel.java, ItemAssets.java and ModelRigs.java were read.
The actual upstream BbModel is compiled externally for compatibility tests;
it is not vendored into this source. Its dominant-axis snapping is forbidden
in generated assets. Static assets omit animations and rig groups.

Minecraft 26.2 supplies officially named (unobfuscated) bytecode and does not
publish separate client mappings in its version metadata. This is checked,
not assumed; older obfuscated clients are rejected by the preparation script.
Dependencies are taken from the exact version JSON, individually SHA-1 checked.
