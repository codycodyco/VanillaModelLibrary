# VanillaModelExtractor asset contract — schema 1

Private handoff only. Official textures are not licensed by this source
repository. Archive root contains `dist/`. Install only
`dist/content/vanillamobs` into `plugins/RPEngine/content/vanillamobs`.

## catalog.json
`schema`: 1; `minecraftVersion`: `26.2`; `namespace`: `vanillamobs`;
`models`: 181 records for the 87 candidate entities and their
supported/unsupported appearances.

Each record: `entityType` (Bukkit uppercase), deterministic `modelId`
(`vanillamobs:<name>`), conjunctive `conditions`, `display`, `supported`,
`limitations`.

Default conditions: `age=adult`, `pose=standing`, `equipment=none`,
`invisible=false`, `upsideDown=false`, `moving=false`, head yaw/pitch 0,
explicit `variant`. Variants add `age=baby`, climate/colour/pattern/gene
conditions. Unsupported records still carry their exact condition set and a
specific reason; they have no `.bbmodel` and no ITEM registration. Conditions
are conjunctive: a warm cow does not match `variant=minecraft:temperate`, a
baby does not match `age=adult`, a dyed sheep does not match `color=white`,
and `jeb_`/sheared are explicit. `zombie_adult` is a deliberate one-model
exception: it uses the official bind pose (arms down) and says so in
`limitations`; it does not claim the vanilla idle arm pose. The adult plains
villager is a second explicit static-pose exception: its folded arms use
`-45 degrees` instead of the official `-0.75 radians` (`-42.9718346348
degrees`) so RP Engine can represent the model losslessly. Its conditions and
limitations must identify the plains, profession-NONE appearance and this
2.0281653652-degree substitution.

The dance-focused 0.3.4 defaults also permit explicit static-pose
substitutions for spider/cave-spider legs, skeleton-family and zombie-family
bind poses, and piglin ears. Each substitution is recorded in `limitations`;
official cubes, per-face UVs, textures, and configured visible overlays remain
required.

The curated villager dance set contains one adult plains model for each
official profession at level 1. IDs use
`villager_plains_<profession>_level_1_adult`; the existing unemployed model is
`villager_adult`. Conditions remain exact and conjunctive. They must not match
other villager types, levels 2–5, babies, held-item states, or work/sleep poses.

Display values are for one ItemDisplay with item display transform NONE, no
parent model, at entity feet, yaw matching the entity. Distances are blocks,
angles degrees. All models use scale=2.5, offsetY=0.001,
yawOffsetDegrees=180; baby geometry is already baby-sized.

## manifest.json
`schema`: 1; `minecraftVersion`; `namespace`; `assetVersion` (`0.2.0` for the
defaults-only build, `0.3.4` for defaults+variants); `sourceClientSha1`;
`catalogSha256`; sorted `files` with `path`, `sha256`, `size`. Paths are
relative to dist, restricted to `content/vanillamobs/`, no traversal.

## report.json
Separates `successes`, `unsupported`, `extractionFailures`, `unverified`,
`failures`, per-model `tests.models`, `tests.variants`, coverage and asset
sizes. `unsupportedByCategory` groups the exact reasons. No blank placeholder
models; no animations, keyframes, meshes or silent cube drops.

`rpEngineCompatibility` records the pinned BbModel revision, element-rotation
count, zero meshes/animations, and the upstream 0.01 coordinate/UV
quantization. `tests.server` records the actual Paper/RP Engine run when
available. Missing clientside visual checks stay `unverified`.

## RP Engine registrations
`pack.yml` contains `bundles: [main]`. `items/mobs.yml` registers every
supported `modelId` local name with `material: PAPER` and `model: <name>`.
Embedded PNGs and per-face UVs are required. Unsupported appearances MUST NOT
be registered or spawned.

## Coordinate, rotation and transparency convention
Baked model position is `[8 - 0.4*x, 8 + 0.4*(24-y), 8 + 0.4*z]` after the
full official part hierarchy. Numeric official cube transforms are decomposed
into a signed permutation (baked into from/to and face mapping) plus one
RP Engine-expressible element rotation. Anything else is rejected.

PNG alpha is preserved and embedded. RP Engine/Minecraft item-model cutout
rendering of translucent edges still requires in-game visual confirmation;
`creaking` eyes are delivered as an ordinary cutout overlay because item
models cannot reproduce additive emissive blending.
